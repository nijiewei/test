/*
 Navicat Premium Data Transfer

 Source Server         : gfdr
 Source Server Type    : MySQL
 Source Server Version : 50547
 Source Host           : 10.1.3.96:3306
 Source Schema         : gfdr

 Target Server Type    : MySQL
 Target Server Version : 50547
 File Encoding         : 65001

 Date: 13/06/2020 17:48:45
*/

SET NAMES utf8;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for gfdr_bm_a1411
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_bm_a1411`;
CREATE TABLE `gfdr_bm_a1411` (
  `DATA_ID` varchar(64) NOT NULL DEFAULT '' COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '分行机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CJRQ_DATE` char(8) DEFAULT NULL COMMENT '采集日期',
  `JRJGDM` varchar(60) DEFAULT NULL COMMENT '金融机构代码',
  `ZBBH` char(5) DEFAULT NULL COMMENT '指标编号',
  `ZBMC` varchar(128) DEFAULT NULL COMMENT '指标名称',
  `YE_AMT` decimal(20,2) DEFAULT NULL COMMENT '余额',
  `REMARKS` varchar(512) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` varchar(512) DEFAULT NULL COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本号',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝描述',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL,
  `RSV2` varchar(180) DEFAULT NULL,
  `RSV3` varchar(180) DEFAULT NULL,
  `RSV4` varchar(180) DEFAULT NULL,
  `RSV5` varchar(180) DEFAULT NULL,
  `C_RSV1` varchar(180) DEFAULT NULL,
  `C_RSV2` varchar(180) DEFAULT NULL,
  `C_RSV3` varchar(180) DEFAULT NULL,
  `C_RSV4` varchar(180) DEFAULT NULL,
  `C_RSV5` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`),
  UNIQUE KEY `CJRQ_DATE` (`CJRQ_DATE`,`JRJGDM`,`ZBBH`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='金融机构资产负债项目月报表（人民币）';

-- ----------------------------
-- Table structure for gfdr_bm_a2411
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_bm_a2411`;
CREATE TABLE `gfdr_bm_a2411` (
  `DATA_ID` varchar(64) NOT NULL DEFAULT '' COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '分行机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CJRQ_DATE` char(8) DEFAULT NULL COMMENT '采集日期',
  `JRJGDM` varchar(60) DEFAULT NULL COMMENT '金融机构代码',
  `ZBBH` char(5) DEFAULT NULL COMMENT '指标编号',
  `ZBMC` varchar(128) DEFAULT NULL COMMENT '指标名称',
  `YE_AMT` decimal(20,2) DEFAULT NULL COMMENT '余额',
  `REMARKS` varchar(512) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` varchar(512) DEFAULT NULL COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本号',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝描述',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL,
  `RSV2` varchar(180) DEFAULT NULL,
  `RSV3` varchar(180) DEFAULT NULL,
  `RSV4` varchar(180) DEFAULT NULL,
  `RSV5` varchar(180) DEFAULT NULL,
  `C_RSV1` varchar(180) DEFAULT NULL,
  `C_RSV2` varchar(180) DEFAULT NULL,
  `C_RSV3` varchar(180) DEFAULT NULL,
  `C_RSV4` varchar(180) DEFAULT NULL,
  `C_RSV5` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`),
  UNIQUE KEY `CJRQ_DATE` (`CJRQ_DATE`,`JRJGDM`,`ZBBH`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='金融机构资产负债项目月报表（外币）';

-- ----------------------------
-- Table structure for gfdr_bm_check_error
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_bm_check_error`;
CREATE TABLE `gfdr_bm_check_error` (
  `DATA_ID` varchar(64) NOT NULL DEFAULT '' COMMENT '数据ID',
  `ORG_ID` varchar(32) DEFAULT NULL,
  `GROUP_ID` varchar(32) DEFAULT NULL,
  `CJRQ_DATE` varchar(32) DEFAULT NULL,
  `TABLE_NAME` varchar(32) DEFAULT NULL,
  `FIELD_NAME` varchar(32) DEFAULT NULL,
  `RULE_ID` varchar(32) DEFAULT NULL,
  `WEAK_RULE` varchar(1) DEFAULT NULL,
  `CHECK_TIME` char(14) DEFAULT NULL,
  `RECORD_ID` varchar(32) DEFAULT NULL,
  `RSV1` varchar(180) DEFAULT NULL,
  `RSV2` varchar(180) DEFAULT NULL,
  `RSV3` varchar(180) DEFAULT NULL,
  `RSV4` varchar(180) DEFAULT NULL,
  `RSV5` varchar(180) DEFAULT NULL,
  `C_RSV1` varchar(180) DEFAULT NULL,
  `C_RSV2` varchar(180) DEFAULT NULL,
  `C_RSV3` varchar(180) DEFAULT NULL,
  `C_RSV4` varchar(180) DEFAULT NULL,
  `C_RSV5` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for gfdr_bm_cldkxx
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_bm_cldkxx`;
CREATE TABLE `gfdr_bm_cldkxx` (
  `DATA_ID` varchar(64) NOT NULL DEFAULT '' COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '分行机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CJRQ_DATE` char(8) DEFAULT NULL COMMENT '采集日期',
  `JRJGDM` varchar(60) DEFAULT NULL COMMENT '金融机构代码',
  `JRJGNBJGH` varchar(30) DEFAULT NULL COMMENT '金融机构内部机构号',
  `JRJGDQDM` char(6) DEFAULT NULL COMMENT '金融机构地区代码',
  `JKRZJDM` varchar(60) DEFAULT NULL COMMENT '借款人证件代码',
  `JKRHY` char(3) DEFAULT NULL COMMENT '借款人行业',
  `JKRDQDM` char(6) DEFAULT NULL COMMENT '借款人地区代码',
  `QYCZRJJCF` varchar(5) DEFAULT NULL COMMENT '企业出资人经济成分',
  `QYGM` char(4) DEFAULT NULL COMMENT '企业规模',
  `DKJJBM` varchar(100) DEFAULT NULL COMMENT '贷款借据编码',
  `DKHTBM` varchar(100) DEFAULT NULL COMMENT '贷款合同编码',
  `DKCPLB` varchar(4) DEFAULT NULL COMMENT '贷款产品类别',
  `DKSJTX` varchar(4) DEFAULT NULL COMMENT '贷款实际投向',
  `DKFFRQ_DATE` char(8) DEFAULT NULL COMMENT '贷款发放日期',
  `DKDQRQ_DATE` char(8) DEFAULT NULL COMMENT '贷款到期日期',
  `DKZQDQRQ_DATE` char(8) DEFAULT NULL COMMENT '贷款展期到期日期',
  `DKBZ` char(3) DEFAULT NULL COMMENT '贷款币种',
  `DKJJYE_AMT` decimal(20,2) DEFAULT NULL COMMENT '贷款借据余额',
  `DKJJZRMBYE_AMT` decimal(20,2) DEFAULT NULL COMMENT '贷款借据折人民币余额',
  `LLSFGD` char(4) DEFAULT NULL COMMENT '利率是否固定',
  `LLSP` decimal(10,5) DEFAULT NULL COMMENT '利率水平',
  `DKDJJZLX` char(4) DEFAULT NULL COMMENT '贷款定价基准类型',
  `JZLL` decimal(10,5) DEFAULT NULL COMMENT '基准利率',
  `DKCZFCFS` varchar(5) DEFAULT NULL COMMENT '贷款财政扶持方式',
  `DKLLZXDJR_DATE` char(8) DEFAULT NULL COMMENT '贷款利率重新定价日',
  `DKDBFS` varchar(3) DEFAULT NULL COMMENT '贷款担保方式',
  `DKZL` char(4) DEFAULT NULL COMMENT '贷款质量',
  `DKZT` char(4) DEFAULT NULL COMMENT '贷款状态',
  `YQLX` char(2) DEFAULT NULL COMMENT '逾期类型',
  `SFSNDK` char(1) DEFAULT NULL COMMENT '是否涉农贷款',
  `SFLSDK` char(1) DEFAULT NULL COMMENT '是否绿色贷款',
  `SFPTDK` char(1) DEFAULT NULL COMMENT '是否平台贷款',
  `SFBZXAJGCDK` char(1) DEFAULT NULL COMMENT '是否保障性安居工程贷款',
  `REMARKS` varchar(512) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` varchar(4000) DEFAULT NULL COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本号',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝描述',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL,
  `RSV2` varchar(180) DEFAULT NULL,
  `RSV3` varchar(180) DEFAULT NULL,
  `RSV4` varchar(180) DEFAULT NULL,
  `RSV5` varchar(180) DEFAULT NULL,
  `C_RSV1` varchar(180) DEFAULT NULL,
  `C_RSV2` varchar(180) DEFAULT NULL,
  `C_RSV3` varchar(180) DEFAULT NULL,
  `C_RSV4` varchar(180) DEFAULT NULL,
  `C_RSV5` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`),
  UNIQUE KEY `CJRQ_DATE` (`CJRQ_DATE`,`JRJGDM`,`DKJJBM`,`DKHTBM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='存量单位贷款基础信息表';

-- ----------------------------
-- Table structure for gfdr_bm_dkdbht
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_bm_dkdbht`;
CREATE TABLE `gfdr_bm_dkdbht` (
  `DATA_ID` varchar(64) NOT NULL DEFAULT '' COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '分行机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CJRQ_DATE` char(8) DEFAULT NULL COMMENT '采集日期',
  `DBHTBM` varchar(100) DEFAULT NULL COMMENT '担保合同编码',
  `DKHTBM` varchar(100) DEFAULT NULL COMMENT '贷款合同编码',
  `DBHTLX` char(2) DEFAULT NULL COMMENT '担保合同类型',
  `DBHTQDRQ_DATE` char(8) DEFAULT NULL COMMENT '担保合同签订日期',
  `DBHTDQRQ_DATE` char(8) DEFAULT NULL COMMENT '担保合同到期日期',
  `DBHTBZ` char(3) DEFAULT NULL COMMENT '担保合同币种',
  `DBHTJE_AMT` decimal(20,2) DEFAULT NULL COMMENT '担保合同金额',
  `DBHTJEZRMB_AMT` decimal(20,2) DEFAULT NULL COMMENT '担保合同金额折人民币',
  `BZRZJLX` varchar(400) DEFAULT NULL COMMENT '保证人证件类型',
  `BZRZJDM` varchar(1000) DEFAULT NULL COMMENT '保证人证件代码',
  `REMARKS` varchar(512) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` varchar(4000) DEFAULT NULL COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本号',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝描述',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL,
  `RSV2` varchar(180) DEFAULT NULL,
  `RSV3` varchar(180) DEFAULT NULL,
  `RSV4` varchar(180) DEFAULT NULL,
  `RSV5` varchar(180) DEFAULT NULL,
  `C_RSV1` varchar(180) DEFAULT NULL,
  `C_RSV2` varchar(180) DEFAULT NULL,
  `C_RSV3` varchar(180) DEFAULT NULL,
  `C_RSV4` varchar(180) DEFAULT NULL,
  `C_RSV5` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`),
  UNIQUE KEY `CJRQ_DATE` (`CJRQ_DATE`,`DBHTBM`,`DKHTBM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='单位贷款担保合同信息表';

-- ----------------------------
-- Table structure for gfdr_bm_dkdbwx
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_bm_dkdbwx`;
CREATE TABLE `gfdr_bm_dkdbwx` (
  `DATA_ID` varchar(64) NOT NULL DEFAULT '' COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '分行机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CJRQ_DATE` char(8) DEFAULT NULL COMMENT '采集日期',
  `DBHTBM` varchar(100) DEFAULT NULL COMMENT '担保合同编码',
  `DKHTBM` varchar(100) DEFAULT NULL COMMENT '贷款合同编码',
  `DBWBM` varchar(60) DEFAULT NULL COMMENT '担保物编码',
  `DBWLB` char(3) DEFAULT NULL COMMENT '担保物类别',
  `QZBH` varchar(300) DEFAULT NULL COMMENT '权证编号',
  `SFDYSW` char(1) DEFAULT NULL COMMENT '是否第一顺位',
  `PGFS` char(3) DEFAULT NULL COMMENT '评估方式',
  `PGFF` char(2) DEFAULT NULL COMMENT '评估方法',
  `PGJZ` decimal(20,2) DEFAULT NULL COMMENT '评估价值',
  `PGJZR_DATE` char(8) DEFAULT NULL COMMENT '评估基准日',
  `DBWZMJZ_AMT` decimal(20,2) DEFAULT NULL COMMENT '担保物账面价值',
  `YXSCQSE_AMT` decimal(20,2) DEFAULT NULL COMMENT '优先受偿权数额',
  `DBWZT` char(2) DEFAULT NULL COMMENT '担保物状态',
  `DZYL` decimal(10,2) DEFAULT NULL COMMENT '抵质押率',
  `REMARKS` varchar(512) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` varchar(4000) DEFAULT NULL COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本号',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝描述',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL,
  `RSV2` varchar(180) DEFAULT NULL,
  `RSV3` varchar(180) DEFAULT NULL,
  `RSV4` varchar(180) DEFAULT NULL,
  `RSV5` varchar(180) DEFAULT NULL,
  `C_RSV1` varchar(180) DEFAULT NULL,
  `C_RSV2` varchar(180) DEFAULT NULL,
  `C_RSV3` varchar(180) DEFAULT NULL,
  `C_RSV4` varchar(180) DEFAULT NULL,
  `C_RSV5` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`),
  UNIQUE KEY `CJRQ_DATE` (`CJRQ_DATE`,`DBHTBM`,`DKHTBM`,`DBWBM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='单位贷款担保物信息表';

-- ----------------------------
-- Table structure for gfdr_bm_dkfsxx
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_bm_dkfsxx`;
CREATE TABLE `gfdr_bm_dkfsxx` (
  `DATA_ID` varchar(64) NOT NULL DEFAULT '' COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '分行机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CJRQ_DATE` char(8) DEFAULT NULL COMMENT '采集日期',
  `JRJGDM` varchar(60) DEFAULT NULL COMMENT '金融机构代码',
  `JRJGNBJGH` varchar(30) DEFAULT NULL COMMENT '金融机构内部机构号',
  `JRJGDQDM` char(6) DEFAULT NULL COMMENT '金融机构地区代码',
  `JKRZJDM` varchar(60) DEFAULT NULL COMMENT '借款人证件代码',
  `JKRHY` char(3) DEFAULT NULL COMMENT '借款人行业',
  `JKRDQDM` char(6) DEFAULT NULL COMMENT '借款人地区代码',
  `QYCZRJJCF` varchar(5) DEFAULT NULL COMMENT '企业出资人经济成分',
  `QYGM` char(4) DEFAULT NULL COMMENT '企业规模',
  `DKJJBM` varchar(100) DEFAULT NULL COMMENT '贷款借据编码',
  `DKHTBM` varchar(100) DEFAULT NULL COMMENT '贷款合同编码',
  `DKCPLB` varchar(4) DEFAULT NULL COMMENT '贷款产品类别',
  `DKSJTX` varchar(4) DEFAULT NULL COMMENT '贷款实际投向',
  `DKFFRQ_DATE` char(8) DEFAULT NULL COMMENT '贷款发放日期',
  `DKDQRQ_DATE` char(8) DEFAULT NULL COMMENT '贷款到期日期',
  `DKSJZZRQ_DATE` char(8) DEFAULT NULL COMMENT '贷款实际终止日期',
  `DKBZ` char(3) DEFAULT NULL COMMENT '贷款币种',
  `DKFSJE_AMT` decimal(20,2) DEFAULT NULL COMMENT '贷款发生金额',
  `DKFSJEZRMB_AMT` decimal(20,2) DEFAULT NULL COMMENT '贷款发生金额折人民币',
  `LLSFGD` char(4) DEFAULT NULL COMMENT '利率是否固定',
  `LLSP` decimal(10,5) DEFAULT NULL COMMENT '利率水平',
  `DKDJJZLX` char(4) DEFAULT NULL COMMENT '贷款定价基准类型',
  `JZLL` decimal(10,5) DEFAULT NULL COMMENT '基准利率',
  `DKCZFCFS` varchar(5) DEFAULT NULL COMMENT '贷款财政扶持方式',
  `DKLLZXDJR_DATE` char(8) DEFAULT NULL COMMENT '贷款利率重新定价日',
  `DKDBFS` varchar(3) DEFAULT NULL COMMENT '贷款担保方式',
  `DKZT` char(4) DEFAULT NULL COMMENT '贷款状态',
  `FFSHBS` char(1) DEFAULT NULL COMMENT '发放/收回标识',
  `SFSNDK` char(1) DEFAULT NULL COMMENT '是否涉农贷款',
  `SFLSDK` char(1) DEFAULT NULL COMMENT '是否绿色贷款',
  `SFPTDK` char(1) DEFAULT NULL COMMENT '是否平台贷款',
  `SFBZXAJGCDK` char(1) DEFAULT NULL COMMENT '是否保障性安居工程贷款',
  `REMARKS` varchar(512) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` varchar(4000) DEFAULT NULL COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本号',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝描述',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL,
  `RSV2` varchar(180) DEFAULT NULL,
  `RSV3` varchar(180) DEFAULT NULL,
  `RSV4` varchar(180) DEFAULT NULL,
  `RSV5` varchar(180) DEFAULT NULL,
  `C_RSV1` varchar(180) DEFAULT NULL,
  `C_RSV2` varchar(180) DEFAULT NULL,
  `C_RSV3` varchar(180) DEFAULT NULL,
  `C_RSV4` varchar(180) DEFAULT NULL,
  `C_RSV5` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`),
  UNIQUE KEY `CJRQ_DATE` (`CJRQ_DATE`,`JRJGDM`,`JRJGNBJGH`,`DKJJBM`,`DKHTBM`,`FFSHBS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='单位贷款发生额信息表';

-- ----------------------------
-- Table structure for gfdr_bm_ex_rate
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_bm_ex_rate`;
CREATE TABLE `gfdr_bm_ex_rate` (
  `DATA_ID` varchar(64) NOT NULL DEFAULT '' COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '分行机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CJRQ_DATE` char(8) DEFAULT NULL COMMENT '采集日期',
  `CODE` char(3) DEFAULT NULL COMMENT '货币编码',
  `NAME` varchar(64) DEFAULT NULL COMMENT '货币名称',
  `UNIT` varchar(64) DEFAULT NULL COMMENT '货币单位',
  `TO_USD` decimal(10,6) DEFAULT NULL COMMENT '对美元折算率',
  `REMARKS` varchar(512) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` varchar(512) DEFAULT NULL COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本号',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝描述',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL,
  `RSV2` varchar(180) DEFAULT NULL,
  `RSV3` varchar(180) DEFAULT NULL,
  `RSV4` varchar(180) DEFAULT NULL,
  `RSV5` varchar(180) DEFAULT NULL,
  `C_RSV1` varchar(180) DEFAULT NULL,
  `C_RSV2` varchar(180) DEFAULT NULL,
  `C_RSV3` varchar(180) DEFAULT NULL,
  `C_RSV4` varchar(180) DEFAULT NULL,
  `C_RSV5` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`),
  UNIQUE KEY `CJRQ_DATE` (`CJRQ_DATE`,`CODE`,`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='各种货币对美元折算率表';

-- ----------------------------
-- Table structure for gfdr_bm_ftykhx
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_bm_ftykhx`;
CREATE TABLE `gfdr_bm_ftykhx` (
  `DATA_ID` varchar(64) NOT NULL DEFAULT '' COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '分行机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CJRQ_DATE` char(8) DEFAULT NULL COMMENT '采集日期',
  `JRJGDM` varchar(60) DEFAULT NULL COMMENT '金融机构代码',
  `KHMC` varchar(200) DEFAULT NULL COMMENT '客户名称',
  `KHDM` varchar(60) DEFAULT NULL COMMENT '客户代码',
  `JBCKZH` varchar(60) DEFAULT NULL COMMENT '基本存款账号',
  `JBZHKHHMC` varchar(200) DEFAULT NULL COMMENT '基本账户开户行名称',
  `ZCZB` decimal(20,2) DEFAULT NULL COMMENT '注册资本',
  `ZCZBBZ` char(3) DEFAULT NULL COMMENT '注册资本币种',
  `SSZB` decimal(20,2) DEFAULT NULL COMMENT '实收资本',
  `SSZBBZ` char(3) DEFAULT NULL COMMENT '实收资本币种',
  `ZZC_AMT` decimal(20,2) DEFAULT NULL COMMENT '总资产',
  `JZC_AMT` decimal(20,2) DEFAULT NULL COMMENT '净资产',
  `SFSSGS` char(1) DEFAULT NULL COMMENT '是否上市公司',
  `SCJLXDGXRQ_DATE` char(8) DEFAULT NULL COMMENT '首次建立信贷关系日期',
  `CYRYS` decimal(10,2) DEFAULT NULL COMMENT '从业人员数',
  `ZCD` varchar(400) DEFAULT NULL COMMENT '注册地',
  `ZCDHZQHDM` char(6) DEFAULT NULL COMMENT '注册地行政区划代码',
  `BGDZ` varchar(400) DEFAULT NULL COMMENT '办公地址',
  `BGDHZQHDM` char(6) DEFAULT NULL COMMENT '办公地行政区划代码',
  `JYZT` char(2) DEFAULT NULL COMMENT '经营状态',
  `CLRQ_DATE` char(8) DEFAULT NULL COMMENT '成立日期',
  `SSHY` char(3) DEFAULT NULL COMMENT '所属行业',
  `QYGM` char(4) DEFAULT NULL COMMENT '企业规模',
  `QYCZRJJCF` varchar(5) DEFAULT NULL COMMENT '企业出资人经济成分',
  `SXED_AMT` decimal(20,2) DEFAULT NULL COMMENT '授信额度',
  `YYED_AMT` decimal(20,2) DEFAULT NULL COMMENT '已用额度',
  `SFGLF` char(1) DEFAULT NULL COMMENT '是否关联方',
  `SJKZRLX` varchar(60) DEFAULT NULL COMMENT '实际控制人类型',
  `SJKZRZJLX` varchar(60) DEFAULT NULL COMMENT '实际控制人证件类型',
  `SJKZRZJDM` varchar(400) DEFAULT NULL COMMENT '实际控制人证件代码',
  `REMARKS` varchar(512) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` varchar(4000) DEFAULT NULL COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本号',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝描述',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL,
  `RSV2` varchar(180) DEFAULT NULL,
  `RSV3` varchar(180) DEFAULT NULL,
  `RSV4` varchar(180) DEFAULT NULL,
  `RSV5` varchar(180) DEFAULT NULL,
  `C_RSV1` varchar(180) DEFAULT NULL,
  `C_RSV2` varchar(180) DEFAULT NULL,
  `C_RSV3` varchar(180) DEFAULT NULL,
  `C_RSV4` varchar(180) DEFAULT NULL,
  `C_RSV5` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`),
  UNIQUE KEY `CJRQ_DATE` (`CJRQ_DATE`,`JRJGDM`,`KHDM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='非同业单位客户信息表';

-- ----------------------------
-- Table structure for gfdr_bm_jrjgfr
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_bm_jrjgfr`;
CREATE TABLE `gfdr_bm_jrjgfr` (
  `DATA_ID` varchar(64) NOT NULL DEFAULT '' COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '分行机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CJRQ_DATE` char(8) DEFAULT NULL COMMENT '采集日期',
  `JRJGDM` varchar(60) DEFAULT NULL COMMENT '金融机构代码',
  `JCXXLX` varchar(128) DEFAULT NULL COMMENT '基础信息类型',
  `ZBBM` char(8) DEFAULT NULL COMMENT '指标编码',
  `ZBMC` varchar(128) DEFAULT NULL COMMENT '指标名称',
  `ZBZ` varchar(512) DEFAULT NULL COMMENT '指标值',
  `REMARKS` varchar(512) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` varchar(4000) DEFAULT NULL COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本号',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝描述',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL,
  `RSV2` varchar(180) DEFAULT NULL,
  `RSV3` varchar(180) DEFAULT NULL,
  `RSV4` varchar(180) DEFAULT NULL,
  `RSV5` varchar(180) DEFAULT NULL,
  `C_RSV1` varchar(180) DEFAULT NULL,
  `C_RSV2` varchar(180) DEFAULT NULL,
  `C_RSV3` varchar(180) DEFAULT NULL,
  `C_RSV4` varchar(180) DEFAULT NULL,
  `C_RSV5` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`),
  UNIQUE KEY `CJRQ_DATE` (`CJRQ_DATE`,`JRJGDM`,`JCXXLX`,`ZBBM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='金融机构法人基础信息表';

-- ----------------------------
-- Table structure for gfdr_bm_jrjgfz
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_bm_jrjgfz`;
CREATE TABLE `gfdr_bm_jrjgfz` (
  `DATA_ID` varchar(64) NOT NULL DEFAULT '' COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '分行机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CJRQ_DATE` char(8) DEFAULT NULL COMMENT '采集日期',
  `JRJGMC` varchar(200) DEFAULT NULL COMMENT '金融机构名称',
  `JRJGDM` varchar(60) DEFAULT NULL COMMENT '金融机构代码',
  `JRJGBM` varchar(30) DEFAULT NULL COMMENT '金融机构编码',
  `NBJGH` varchar(30) DEFAULT NULL COMMENT '内部机构号',
  `JGJB` char(2) DEFAULT NULL COMMENT '机构级别',
  `ZSSJGLJGMC` varchar(200) DEFAULT NULL COMMENT '直属上级管理机构名称',
  `ZSSJGLJGJRJGBM` varchar(30) DEFAULT NULL COMMENT '直属上级管理机构金融机构编码',
  `ZSSJGLJGNBJGH` varchar(30) DEFAULT NULL COMMENT '直属上级管理机构内部机构号',
  `ZCDZ` varchar(400) DEFAULT NULL COMMENT '注册地址',
  `ZCDHZQHDM` char(6) DEFAULT NULL COMMENT '注册地行政区划代码',
  `BGDZ` varchar(400) DEFAULT NULL COMMENT '办公地址',
  `BGDHZQHDM` char(6) DEFAULT NULL COMMENT '办公地行政区划代码',
  `CLSJ_DATE` char(8) DEFAULT NULL COMMENT '成立时间',
  `YYZT` char(2) DEFAULT NULL COMMENT '营业状态',
  `REMARKS` varchar(512) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` varchar(4000) DEFAULT NULL COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本号',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝描述',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL,
  `RSV2` varchar(180) DEFAULT NULL,
  `RSV3` varchar(180) DEFAULT NULL,
  `RSV4` varchar(180) DEFAULT NULL,
  `RSV5` varchar(180) DEFAULT NULL,
  `C_RSV1` varchar(180) DEFAULT NULL,
  `C_RSV2` varchar(180) DEFAULT NULL,
  `C_RSV3` varchar(180) DEFAULT NULL,
  `C_RSV4` varchar(180) DEFAULT NULL,
  `C_RSV5` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`),
  UNIQUE KEY `CJRQ_DATE` (`CJRQ_DATE`,`JRJGDM`,`NBJGH`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='金融机构分支机构信息表';

-- ----------------------------
-- Table structure for gfdr_bm_rpt_cbrc_cfg
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_bm_rpt_cbrc_cfg`;
CREATE TABLE `gfdr_bm_rpt_cbrc_cfg` (
  `DATA_ID` varchar(32) NOT NULL,
  `DATA_DATE` char(8) DEFAULT NULL,
  `CORP_ID` varchar(14) DEFAULT NULL,
  `ORG_ID` varchar(14) DEFAULT NULL,
  `GROUP_ID` varchar(14) DEFAULT NULL,
  `YXJGDM` varchar(30) DEFAULT NULL,
  `NBJGH` varchar(30) DEFAULT NULL,
  `JRXKZH` varchar(30) DEFAULT NULL,
  `YXJGMC` varchar(200) DEFAULT NULL,
  `CJRQ_DATE` varchar(8) DEFAULT NULL,
  `REMARKS` varchar(512) DEFAULT NULL,
  `RSV1` varchar(180) DEFAULT NULL,
  `RSV2` varchar(180) DEFAULT NULL,
  `RSV3` varchar(180) DEFAULT NULL,
  `RSV4` varchar(180) DEFAULT NULL,
  `RSV5` varchar(180) DEFAULT NULL,
  `P_NBJGH` varchar(32) DEFAULT NULL,
  `REAL_NBJGH` varchar(32) DEFAULT NULL,
  `IS_REPORT` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for gfdr_bm_rpt_cfg
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_bm_rpt_cfg`;
CREATE TABLE `gfdr_bm_rpt_cfg` (
  `DATA_ID` varchar(64) NOT NULL DEFAULT '' COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '分行机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `INQ_ORG_ID` char(24) DEFAULT NULL COMMENT '查询机构号',
  `INQ_GROUP_ID` char(24) DEFAULT NULL COMMENT '查询组号',
  `FILE_NAME` varchar(64) DEFAULT NULL COMMENT '文件名',
  `TABLE_NAME` varchar(64) DEFAULT NULL COMMENT '表名',
  `CON_MODE` char(1) DEFAULT NULL COMMENT '集中采集模式',
  `LAST_MODE` char(1) DEFAULT NULL COMMENT '持续采集模式',
  `IS_MONTH` char(1) DEFAULT NULL COMMENT '是否月报',
  `IS_QUARTER` char(1) DEFAULT NULL COMMENT '是否季报',
  `IS_HALF` char(1) DEFAULT NULL COMMENT '是否半年报',
  `IS_YEAR` char(1) DEFAULT NULL COMMENT '是否年报',
  `SEPARATOR` varchar(12) DEFAULT NULL COMMENT '分割符',
  `REMARKS` text COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝描述',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `TEMP_TABLE_NAME` varchar(100) DEFAULT NULL COMMENT '上报临时表表名',
  `REPORT_TYPE` varchar(50) DEFAULT NULL COMMENT '报表类型',
  `QUERY_FUNCID` varchar(20) DEFAULT NULL COMMENT '查询页面菜单ID',
  `REVISE_FUNCID` varchar(20) DEFAULT NULL COMMENT '补录页面菜单ID',
  `FILE_FUNCID` varchar(20) DEFAULT NULL COMMENT '上报文件查询菜单ID',
  `DIVIDE_COLUMN` varchar(64) DEFAULT NULL COMMENT '拆分字段',
  `DIVIDE_RULE` varchar(20) DEFAULT NULL COMMENT '拆分规则',
  `CJRQ_FLAG` varchar(2) DEFAULT NULL COMMENT '采集日期规则',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for gfdr_bm_rpt_cfg_dtl
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_bm_rpt_cfg_dtl`;
CREATE TABLE `gfdr_bm_rpt_cfg_dtl` (
  `DATA_ID` varchar(64) NOT NULL DEFAULT '' COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '分行机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `INQ_ORG_ID` char(24) DEFAULT NULL COMMENT '查询机构号',
  `INQ_GROUP_ID` char(24) DEFAULT NULL COMMENT '查询组号',
  `RPT_CFG_DATA_ID` char(32) DEFAULT NULL COMMENT '报文生成配置表ID',
  `COLUMN_NAME` varchar(64) DEFAULT NULL COMMENT '字段名',
  `COLUMN_TYPE` varchar(12) DEFAULT NULL COMMENT '字段类型',
  `SEQ_NO` char(3) DEFAULT NULL COMMENT '字段顺序',
  `SECRET_MODE` varchar(200) DEFAULT NULL COMMENT '隐私处理模式',
  `STATUS` char(1) DEFAULT NULL COMMENT '是否有效',
  `REMARKS` varchar(512) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` varchar(512) DEFAULT NULL COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝描述',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `KZYY` varchar(2000) DEFAULT NULL COMMENT '空值原因',
  `JJFA` varchar(2000) DEFAULT NULL COMMENT '解决方案',
  `JJJD` varchar(2000) DEFAULT NULL COMMENT '解决进度',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for gfdr_bm_rpt_condition
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_bm_rpt_condition`;
CREATE TABLE `gfdr_bm_rpt_condition` (
  `DATA_ID` varchar(32) DEFAULT NULL,
  `DATA_DATE` char(8) DEFAULT NULL,
  `CORP_ID` varchar(14) DEFAULT NULL,
  `ORG_ID` varchar(14) DEFAULT NULL,
  `GROUP_ID` varchar(14) DEFAULT NULL,
  `NBJGH` varchar(30) DEFAULT NULL,
  `FILE_NAME` varchar(64) DEFAULT NULL,
  `DIVIDE_RULE` varchar(2) DEFAULT NULL,
  `WHERE_CONDITION` varchar(400) DEFAULT NULL,
  `RSV1` varchar(180) DEFAULT NULL,
  `RSV2` varchar(180) DEFAULT NULL,
  `RSV3` varchar(180) DEFAULT NULL,
  `RSV4` varchar(180) DEFAULT NULL,
  `RSV5` varchar(180) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for gfdr_bm_rpt_qrycol_rel
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_bm_rpt_qrycol_rel`;
CREATE TABLE `gfdr_bm_rpt_qrycol_rel` (
  `DATA_ID` varchar(64) NOT NULL DEFAULT '' COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '分行机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `INQ_ORG_ID` char(24) DEFAULT NULL COMMENT '查询机构号',
  `INQ_GROUP_ID` char(24) DEFAULT NULL COMMENT '查询组号',
  `REPORT_CODE` varchar(32) DEFAULT NULL COMMENT '报表编号',
  `REPORT_NAME` varchar(256) DEFAULT NULL COMMENT '报表名称',
  `QUERY_COLUMN_NAME` varchar(4000) DEFAULT NULL COMMENT '查询字段名',
  `QUERY_COLUMN_COMMENT` varchar(4000) DEFAULT NULL COMMENT '查询字段中文名',
  `QUERY_TYPE` varchar(32) DEFAULT NULL COMMENT '查询方式',
  `REQUIRE` varchar(32) DEFAULT NULL COMMENT '是否必填',
  `EDIT_TYPE` varchar(32) DEFAULT NULL COMMENT '编辑类型',
  `DATA_TYPE` varchar(32) DEFAULT NULL COMMENT '数据类型',
  `COLUMN_LENGTH` varchar(32) DEFAULT NULL COMMENT '允许最大长度',
  `READONLY` varchar(32) DEFAULT NULL COMMENT '只读状态',
  `DATA_DIC` varchar(32) DEFAULT NULL COMMENT '数据字典',
  `CQ_QUERY` varchar(512) DEFAULT NULL COMMENT 'CQ查询',
  `REMARKS` varchar(512) DEFAULT NULL COMMENT '备注',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` varchar(512) DEFAULT NULL COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本号',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝描述',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `C_RSV1` varchar(180) DEFAULT NULL COMMENT '扩展字段1',
  `C_RSV2` varchar(180) DEFAULT NULL COMMENT '扩展字段2',
  `C_RSV3` varchar(180) DEFAULT NULL COMMENT '扩展字段3',
  `C_RSV4` varchar(180) DEFAULT NULL COMMENT '扩展字段4',
  `C_RSV5` varchar(180) DEFAULT NULL COMMENT '扩展字段5',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for gfdr_bm_rpt_task
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_bm_rpt_task`;
CREATE TABLE `gfdr_bm_rpt_task` (
  `DATA_ID` char(32) NOT NULL,
  `DATA_DATE` char(8) DEFAULT NULL,
  `CORP_ID` varchar(14) DEFAULT NULL,
  `ORG_ID` varchar(14) DEFAULT NULL,
  `GROUP_ID` varchar(14) DEFAULT NULL,
  `INQ_ORG_ID` char(24) DEFAULT NULL,
  `INQ_GROUP_ID` char(24) DEFAULT NULL,
  `NBJGH` varchar(30) DEFAULT NULL,
  `REAL_NBJGH` varchar(30) DEFAULT NULL,
  `DIVIDE_RULE` varchar(2) DEFAULT NULL,
  `FILE_PATH` varchar(64) DEFAULT NULL,
  `FILE_NAME` varchar(64) DEFAULT NULL,
  `REPORT_CODE` varchar(64) DEFAULT NULL,
  `REPORT_NAME` varchar(100) DEFAULT NULL,
  `REPORT_TABLE_NAME` varchar(64) DEFAULT NULL,
  `FILE_TABLE_NAME` varchar(64) DEFAULT NULL,
  `PERIODS_NO` varchar(20) DEFAULT NULL,
  `CJRQ_DATE` char(8) DEFAULT NULL,
  `TASK_STATUS` varchar(2) DEFAULT NULL,
  `START_DATE` char(8) DEFAULT NULL,
  `END_DATE` char(8) DEFAULT NULL,
  `DIVIDE_SQL` varchar(4000) DEFAULT NULL,
  `WHERE_SQL` varchar(4000) DEFAULT NULL,
  `VALIDATE_SQL` varchar(4000) DEFAULT NULL,
  `IS_VALIDATED` varchar(2) DEFAULT NULL,
  `CJRQ_FLAG` varchar(2) DEFAULT NULL,
  `DIVIDE_COLUMN` varchar(64) DEFAULT NULL,
  `START_TIME` varchar(14) DEFAULT NULL,
  `END_TIME` varchar(14) DEFAULT NULL,
  `REMARKS` varchar(2000) DEFAULT NULL,
  `CHECK_FLAG` char(1) DEFAULT NULL,
  `CHECK_DESC` varchar(512) DEFAULT NULL,
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL,
  `NEXT_ACTION` char(2) DEFAULT NULL,
  `DATA_STATUS` char(2) DEFAULT NULL,
  `DATA_FLAG` char(1) DEFAULT NULL,
  `DATA_SOURCE` char(1) DEFAULT NULL,
  `DATA_VERSION` int(11) DEFAULT NULL,
  `DATA_CRT_USER` varchar(20) DEFAULT NULL,
  `DATA_CRT_DATE` char(8) DEFAULT NULL,
  `DATA_CRT_TIME` char(14) DEFAULT NULL,
  `DATA_CHG_USER` varchar(20) DEFAULT NULL,
  `DATA_CHG_DATE` char(8) DEFAULT NULL,
  `DATA_CHG_TIME` char(14) DEFAULT NULL,
  `RSV1` varchar(180) DEFAULT NULL,
  `RSV2` varchar(180) DEFAULT NULL,
  `RSV3` varchar(180) DEFAULT NULL,
  `RSV4` varchar(180) DEFAULT NULL,
  `RSV5` varchar(180) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for gfdr_bm_todo_task
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_bm_todo_task`;
CREATE TABLE `gfdr_bm_todo_task` (
  `DATA_ID` varchar(64) NOT NULL DEFAULT '' COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '分行机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '业务条线号',
  `REPORT_TYPE` varchar(128) DEFAULT NULL COMMENT '报表类型',
  `REPORT_CODE` varchar(32) DEFAULT NULL COMMENT '报表编码',
  `REPORT_NAME` varchar(128) DEFAULT NULL COMMENT '报表名称',
  `REPORT_DATE` varchar(32) DEFAULT NULL COMMENT '报表日期',
  `TASK_TYPE` char(1) DEFAULT NULL COMMENT '任务类型',
  `P_TASK_ID` varchar(32) DEFAULT NULL COMMENT '主任务任务ID',
  `CHECK_STATUS` varchar(2) DEFAULT NULL COMMENT '校验状态',
  `TASK_STATUS` char(2) DEFAULT NULL COMMENT '任务状态',
  `REVISE_FUNC_ID` varchar(64) DEFAULT NULL COMMENT '补录页面菜单ID',
  `REVIEW_FUNC_ID` varchar(64) DEFAULT NULL COMMENT '复核页面菜单ID',
  `APPROVE_FUNC_ID` varchar(64) DEFAULT NULL COMMENT '审核页面菜单ID',
  `PACKAGE_FUNC_ID` varchar(64) DEFAULT NULL COMMENT '打包页面菜单ID',
  `REMARKS` text COMMENT '备注',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验描述',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本号',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝描述',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据习惯用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `C_RSV1` varchar(180) DEFAULT NULL COMMENT '扩展字段1',
  `C_RSV2` varchar(180) DEFAULT NULL COMMENT '扩展字段2',
  `C_RSV3` varchar(180) DEFAULT NULL COMMENT '扩展字段3',
  `C_RSV4` varchar(180) DEFAULT NULL COMMENT '扩展字段4',
  `C_RSV5` varchar(180) DEFAULT NULL COMMENT '扩展字段5',
  `TASK_NAME` varchar(100) DEFAULT NULL COMMENT '任务名称',
  `TASK_ID` varchar(100) DEFAULT NULL COMMENT '任务ID',
  `TASK_MODULE` varchar(100) DEFAULT NULL COMMENT '任务模块',
  PRIMARY KEY (`DATA_ID`),
  KEY `GFDR_BM_TODO_TASK_INDEX1` (`ORG_ID`,`GROUP_ID`,`REPORT_CODE`),
  KEY `GFDR_BM_TODO_TASK_INDEX2` (`REPORT_DATE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for gfdr_ck_zb_dtl
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_ck_zb_dtl`;
CREATE TABLE `gfdr_ck_zb_dtl` (
  `DATA_ID` varchar(100) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '分行机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CJRQ_DATE` char(8) DEFAULT NULL COMMENT '采集日期',
  `JRJGDM` varchar(60) DEFAULT NULL COMMENT '金融机构代码',
  `JKRHY` char(3) DEFAULT NULL COMMENT '借款人行业',
  `DKCPLB` varchar(4) DEFAULT NULL COMMENT '贷款产品类别',
  `DKBZ` char(3) DEFAULT NULL COMMENT '贷款币种',
  `DKJJYE_AMT` decimal(20,2) DEFAULT NULL COMMENT '贷款借据余额',
  `DKJJZRMBYE_AMT` decimal(20,2) DEFAULT NULL COMMENT '贷款借据折人民币余额',
  `USD_AMT` decimal(20,2) DEFAULT NULL COMMENT '美元余额',
  `REMARKS` varchar(512) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` varchar(512) DEFAULT NULL COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本号',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝描述',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL,
  `RSV2` varchar(180) DEFAULT NULL,
  `RSV3` varchar(180) DEFAULT NULL,
  `RSV4` varchar(180) DEFAULT NULL,
  `RSV5` varchar(180) DEFAULT NULL,
  `C_RSV1` varchar(180) DEFAULT NULL,
  `C_RSV2` varchar(180) DEFAULT NULL,
  `C_RSV3` varchar(180) DEFAULT NULL,
  `C_RSV4` varchar(180) DEFAULT NULL,
  `C_RSV5` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='指标校验明细表';

-- ----------------------------
-- Table structure for gfdr_ck_zb_hz
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_ck_zb_hz`;
CREATE TABLE `gfdr_ck_zb_hz` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '分行机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CJRQ_DATE` char(8) DEFAULT NULL COMMENT '采集日期',
  `JRJGDM` varchar(60) DEFAULT NULL COMMENT '金融机构代码',
  `JKRHY` char(3) DEFAULT NULL COMMENT '借款人行业',
  `DKCPLB` varchar(4) DEFAULT NULL COMMENT '贷款产品类别',
  `DKBZ` char(3) DEFAULT NULL COMMENT '贷款币种',
  `DKJJYE_AMT` decimal(20,2) DEFAULT NULL COMMENT '贷款借据余额',
  `DKJJZRMBYE_AMT` decimal(20,2) DEFAULT NULL COMMENT '贷款借据折人民币余额',
  `USD_AMT` decimal(20,2) DEFAULT NULL COMMENT '美元余额',
  `REMARKS` varchar(512) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` varchar(512) DEFAULT NULL COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本号',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝描述',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL,
  `RSV2` varchar(180) DEFAULT NULL,
  `RSV3` varchar(180) DEFAULT NULL,
  `RSV4` varchar(180) DEFAULT NULL,
  `RSV5` varchar(180) DEFAULT NULL,
  `C_RSV1` varchar(180) DEFAULT NULL,
  `C_RSV2` varchar(180) DEFAULT NULL,
  `C_RSV3` varchar(180) DEFAULT NULL,
  `C_RSV4` varchar(180) DEFAULT NULL,
  `C_RSV5` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='指标校验最终表';

-- ----------------------------
-- Table structure for gfdr_ck_zb_result
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_ck_zb_result`;
CREATE TABLE `gfdr_ck_zb_result` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '分行机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CJRQ_DATE` char(8) DEFAULT NULL COMMENT '采集日期',
  `JRJGDM` varchar(60) DEFAULT NULL COMMENT '金融机构代码',
  `JKRHY` char(3) DEFAULT NULL COMMENT '借款人行业',
  `DKCPLB` varchar(4) DEFAULT NULL COMMENT '贷款产品类别',
  `DKBZ` char(3) DEFAULT NULL COMMENT '贷款币种',
  `DKJJYE_AMT` decimal(20,2) DEFAULT NULL COMMENT '贷款借据余额',
  `DKJJZRMBYE_AMT` decimal(20,2) DEFAULT NULL COMMENT '贷款借据折人民币余额',
  `ZBBH` varchar(128) DEFAULT NULL COMMENT '指标编号',
  `ZBMC` varchar(128) DEFAULT NULL COMMENT '指标名称',
  `YE_AMT` decimal(20,2) DEFAULT NULL COMMENT '余额',
  `CK_AMT` decimal(20,2) DEFAULT NULL COMMENT '差额',
  `CK_PER` decimal(8,4) DEFAULT NULL COMMENT '偏差比例',
  `REMARKS` varchar(512) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` varchar(512) DEFAULT NULL COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本号',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝描述',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL,
  `RSV2` varchar(180) DEFAULT NULL,
  `RSV3` varchar(180) DEFAULT NULL,
  `RSV4` varchar(180) DEFAULT NULL,
  `RSV5` varchar(180) DEFAULT NULL,
  `C_RSV1` varchar(180) DEFAULT NULL,
  `C_RSV2` varchar(180) DEFAULT NULL,
  `C_RSV3` varchar(180) DEFAULT NULL,
  `C_RSV4` varchar(180) DEFAULT NULL,
  `C_RSV5` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='指标校验结果表';

-- ----------------------------
-- Table structure for gfdr_file_cldkxx
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_file_cldkxx`;
CREATE TABLE `gfdr_file_cldkxx` (
  `DATA_ID` varchar(64) NOT NULL DEFAULT '' COMMENT '数据ID',
  `DATA_DATE` varchar(32) DEFAULT NULL,
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '分行机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CJRQ_DATE` varchar(32) DEFAULT NULL,
  `JRJGDM` varchar(60) DEFAULT NULL COMMENT '金融机构代码',
  `JRJGNBJGH` varchar(30) DEFAULT NULL COMMENT '金融机构内部机构号',
  `JRJGDQDM` char(6) DEFAULT NULL COMMENT '金融机构地区代码',
  `JKRZJDM` varchar(60) DEFAULT NULL COMMENT '借款人证件代码',
  `JKRHY` char(3) DEFAULT NULL COMMENT '借款人行业',
  `JKRDQDM` char(6) DEFAULT NULL COMMENT '借款人地区代码',
  `QYCZRJJCF` varchar(5) DEFAULT NULL COMMENT '企业出资人经济成分',
  `QYGM` char(4) DEFAULT NULL COMMENT '企业规模',
  `DKJJBM` varchar(100) DEFAULT NULL COMMENT '贷款借据编码',
  `DKHTBM` varchar(100) DEFAULT NULL COMMENT '贷款合同编码',
  `DKCPLB` varchar(4) DEFAULT NULL COMMENT '贷款产品类别',
  `DKSJTX` varchar(4) DEFAULT NULL COMMENT '贷款实际投向',
  `DKFFRQ_DATE` varchar(32) DEFAULT NULL,
  `DKDQRQ_DATE` varchar(32) DEFAULT NULL,
  `DKZQDQRQ_DATE` varchar(32) DEFAULT NULL,
  `DKBZ` char(3) DEFAULT NULL COMMENT '贷款币种',
  `DKJJYE_AMT` decimal(20,2) DEFAULT NULL COMMENT '贷款借据余额',
  `DKJJZRMBYE_AMT` decimal(20,2) DEFAULT NULL COMMENT '贷款借据折人民币余额',
  `LLSFGD` char(4) DEFAULT NULL COMMENT '利率是否固定',
  `LLSP` decimal(10,5) DEFAULT NULL COMMENT '利率水平',
  `DKDJJZLX` char(4) DEFAULT NULL COMMENT '贷款定价基准类型',
  `JZLL` decimal(10,5) DEFAULT NULL COMMENT '基准利率',
  `DKCZFCFS` varchar(5) DEFAULT NULL COMMENT '贷款财政扶持方式',
  `DKLLZXDJR_DATE` varchar(32) DEFAULT NULL,
  `DKDBFS` varchar(3) DEFAULT NULL COMMENT '贷款担保方式',
  `DKZL` char(4) DEFAULT NULL COMMENT '贷款质量',
  `DKZT` char(4) DEFAULT NULL COMMENT '贷款状态',
  `YQLX` char(2) DEFAULT NULL COMMENT '逾期类型',
  `SFSNDK` char(1) DEFAULT NULL COMMENT '是否涉农贷款',
  `SFLSDK` char(1) DEFAULT NULL COMMENT '是否绿色贷款',
  `SFPTDK` char(1) DEFAULT NULL COMMENT '是否平台贷款',
  `SFBZXAJGCDK` char(1) DEFAULT NULL COMMENT '是否保障性安居工程贷款',
  `REMARKS` varchar(512) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` varchar(512) DEFAULT NULL COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本号',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝描述',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` varchar(32) DEFAULT NULL,
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` varchar(32) DEFAULT NULL,
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` varchar(32) DEFAULT NULL,
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL,
  `RSV2` varchar(180) DEFAULT NULL,
  `RSV3` varchar(180) DEFAULT NULL,
  `RSV4` varchar(180) DEFAULT NULL,
  `RSV5` varchar(180) DEFAULT NULL,
  `C_RSV1` varchar(180) DEFAULT NULL,
  `C_RSV2` varchar(180) DEFAULT NULL,
  `C_RSV3` varchar(180) DEFAULT NULL,
  `C_RSV4` varchar(180) DEFAULT NULL,
  `C_RSV5` varchar(180) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for gfdr_file_dkdbht
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_file_dkdbht`;
CREATE TABLE `gfdr_file_dkdbht` (
  `DATA_ID` varchar(64) NOT NULL DEFAULT '' COMMENT '数据ID',
  `DATA_DATE` varchar(32) DEFAULT NULL,
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '分行机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CJRQ_DATE` varchar(32) DEFAULT NULL,
  `DBHTBM` varchar(100) DEFAULT NULL COMMENT '担保合同编码',
  `DKHTBM` varchar(100) DEFAULT NULL COMMENT '贷款合同编码',
  `DBHTLX` char(2) DEFAULT NULL COMMENT '担保合同类型',
  `DBHTQDRQ_DATE` varchar(32) DEFAULT NULL,
  `DBHTDQRQ_DATE` varchar(32) DEFAULT NULL,
  `DBHTBZ` char(3) DEFAULT NULL COMMENT '担保合同币种',
  `DBHTJE_AMT` decimal(20,2) DEFAULT NULL COMMENT '担保合同金额',
  `DBHTJEZRMB_AMT` decimal(20,2) DEFAULT NULL COMMENT '担保合同金额折人民币',
  `BZRZJLX` varchar(400) DEFAULT NULL COMMENT '保证人证件类型',
  `BZRZJDM` varchar(1000) DEFAULT NULL COMMENT '保证人证件代码',
  `REMARKS` varchar(512) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` varchar(512) DEFAULT NULL COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本号',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝描述',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` varchar(32) DEFAULT NULL,
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` varchar(32) DEFAULT NULL,
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` varchar(32) DEFAULT NULL,
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL,
  `RSV2` varchar(180) DEFAULT NULL,
  `RSV3` varchar(180) DEFAULT NULL,
  `RSV4` varchar(180) DEFAULT NULL,
  `RSV5` varchar(180) DEFAULT NULL,
  `C_RSV1` varchar(180) DEFAULT NULL,
  `C_RSV2` varchar(180) DEFAULT NULL,
  `C_RSV3` varchar(180) DEFAULT NULL,
  `C_RSV4` varchar(180) DEFAULT NULL,
  `C_RSV5` varchar(180) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for gfdr_file_dkdbwx
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_file_dkdbwx`;
CREATE TABLE `gfdr_file_dkdbwx` (
  `DATA_ID` varchar(64) NOT NULL DEFAULT '' COMMENT '数据ID',
  `DATA_DATE` varchar(32) DEFAULT NULL,
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '分行机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CJRQ_DATE` varchar(32) DEFAULT NULL,
  `DBHTBM` varchar(100) DEFAULT NULL COMMENT '担保合同编码',
  `DKHTBM` varchar(100) DEFAULT NULL COMMENT '贷款合同编码',
  `DBWBM` varchar(60) DEFAULT NULL COMMENT '担保物编码',
  `DBWLB` char(3) DEFAULT NULL COMMENT '担保物类别',
  `QZBH` varchar(300) DEFAULT NULL COMMENT '权证编号',
  `SFDYSW` char(1) DEFAULT NULL COMMENT '是否第一顺位',
  `PGFS` char(3) DEFAULT NULL COMMENT '评估方式',
  `PGFF` char(2) DEFAULT NULL COMMENT '评估方法',
  `PGJZ` decimal(20,2) DEFAULT NULL COMMENT '评估价值',
  `PGJZR_DATE` varchar(32) DEFAULT NULL,
  `DBWZMJZ_AMT` decimal(20,2) DEFAULT NULL COMMENT '担保物账面价值',
  `YXSCQSE_AMT` decimal(20,2) DEFAULT NULL COMMENT '优先受偿权数额',
  `DBWZT` char(2) DEFAULT NULL COMMENT '担保物状态',
  `DZYL` decimal(10,2) DEFAULT NULL COMMENT '抵质押率',
  `REMARKS` varchar(512) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` varchar(512) DEFAULT NULL COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本号',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝描述',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` varchar(32) DEFAULT NULL,
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` varchar(32) DEFAULT NULL,
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` varchar(32) DEFAULT NULL,
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL,
  `RSV2` varchar(180) DEFAULT NULL,
  `RSV3` varchar(180) DEFAULT NULL,
  `RSV4` varchar(180) DEFAULT NULL,
  `RSV5` varchar(180) DEFAULT NULL,
  `C_RSV1` varchar(180) DEFAULT NULL,
  `C_RSV2` varchar(180) DEFAULT NULL,
  `C_RSV3` varchar(180) DEFAULT NULL,
  `C_RSV4` varchar(180) DEFAULT NULL,
  `C_RSV5` varchar(180) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for gfdr_file_dkfsxx
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_file_dkfsxx`;
CREATE TABLE `gfdr_file_dkfsxx` (
  `DATA_ID` varchar(64) NOT NULL DEFAULT '' COMMENT '数据ID',
  `DATA_DATE` varchar(32) DEFAULT NULL,
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '分行机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CJRQ_DATE` varchar(32) DEFAULT NULL,
  `JRJGDM` varchar(60) DEFAULT NULL COMMENT '金融机构代码',
  `JRJGNBJGH` varchar(30) DEFAULT NULL COMMENT '金融机构内部机构号',
  `JRJGDQDM` char(6) DEFAULT NULL COMMENT '金融机构地区代码',
  `JKRZJDM` varchar(60) DEFAULT NULL COMMENT '借款人证件代码',
  `JKRHY` char(3) DEFAULT NULL COMMENT '借款人行业',
  `JKRDQDM` char(6) DEFAULT NULL COMMENT '借款人地区代码',
  `QYCZRJJCF` varchar(5) DEFAULT NULL COMMENT '企业出资人经济成分',
  `QYGM` char(4) DEFAULT NULL COMMENT '企业规模',
  `DKJJBM` varchar(100) DEFAULT NULL COMMENT '贷款借据编码',
  `DKHTBM` varchar(100) DEFAULT NULL COMMENT '贷款合同编码',
  `DKCPLB` varchar(4) DEFAULT NULL COMMENT '贷款产品类别',
  `DKSJTX` varchar(4) DEFAULT NULL COMMENT '贷款实际投向',
  `DKFFRQ_DATE` varchar(32) DEFAULT NULL,
  `DKDQRQ_DATE` varchar(32) DEFAULT NULL,
  `DKSJZZRQ_DATE` varchar(32) DEFAULT NULL,
  `DKBZ` char(3) DEFAULT NULL COMMENT '贷款币种',
  `DKFSJE_AMT` decimal(20,2) DEFAULT NULL COMMENT '贷款发生金额',
  `DKFSJEZRMB_AMT` decimal(20,2) DEFAULT NULL COMMENT '贷款发生金额折人民币',
  `LLSFGD` char(4) DEFAULT NULL COMMENT '利率是否固定',
  `LLSP` decimal(10,5) DEFAULT NULL COMMENT '利率水平',
  `DKDJJZLX` char(4) DEFAULT NULL COMMENT '贷款定价基准类型',
  `JZLL` decimal(10,5) DEFAULT NULL COMMENT '基准利率',
  `DKCZFCFS` varchar(5) DEFAULT NULL COMMENT '贷款财政扶持方式',
  `DKLLZXDJR_DATE` varchar(32) DEFAULT NULL,
  `DKDBFS` varchar(3) DEFAULT NULL COMMENT '贷款担保方式',
  `DKZT` char(4) DEFAULT NULL COMMENT '贷款状态',
  `FFSHBS` char(1) DEFAULT NULL COMMENT '发放/收回标识',
  `SFSNDK` char(1) DEFAULT NULL COMMENT '是否涉农贷款',
  `SFLSDK` char(1) DEFAULT NULL COMMENT '是否绿色贷款',
  `SFPTDK` char(1) DEFAULT NULL COMMENT '是否平台贷款',
  `SFBZXAJGCDK` char(1) DEFAULT NULL COMMENT '是否保障性安居工程贷款',
  `REMARKS` varchar(512) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` varchar(512) DEFAULT NULL COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本号',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝描述',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` varchar(32) DEFAULT NULL,
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` varchar(32) DEFAULT NULL,
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` varchar(32) DEFAULT NULL,
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL,
  `RSV2` varchar(180) DEFAULT NULL,
  `RSV3` varchar(180) DEFAULT NULL,
  `RSV4` varchar(180) DEFAULT NULL,
  `RSV5` varchar(180) DEFAULT NULL,
  `C_RSV1` varchar(180) DEFAULT NULL,
  `C_RSV2` varchar(180) DEFAULT NULL,
  `C_RSV3` varchar(180) DEFAULT NULL,
  `C_RSV4` varchar(180) DEFAULT NULL,
  `C_RSV5` varchar(180) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for gfdr_file_ftykhx
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_file_ftykhx`;
CREATE TABLE `gfdr_file_ftykhx` (
  `DATA_ID` varchar(64) NOT NULL DEFAULT '' COMMENT '数据ID',
  `DATA_DATE` varchar(32) DEFAULT NULL,
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '分行机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CJRQ_DATE` varchar(32) DEFAULT NULL,
  `JRJGDM` varchar(60) DEFAULT NULL COMMENT '金融机构代码',
  `KHMC` varchar(200) DEFAULT NULL COMMENT '客户名称',
  `KHDM` varchar(60) DEFAULT NULL COMMENT '客户代码',
  `JBCKZH` varchar(60) DEFAULT NULL COMMENT '基本存款账号',
  `JBZHKHHMC` varchar(200) DEFAULT NULL COMMENT '基本账户开户行名称',
  `ZCZB` decimal(20,2) DEFAULT NULL COMMENT '注册资本',
  `ZCZBBZ` char(3) DEFAULT NULL COMMENT '注册资本币种',
  `SSZB` decimal(20,2) DEFAULT NULL COMMENT '实收资本',
  `SSZBBZ` char(3) DEFAULT NULL COMMENT '实收资本币种',
  `ZZC_AMT` decimal(20,2) DEFAULT NULL COMMENT '总资产',
  `JZC_AMT` decimal(20,2) DEFAULT NULL COMMENT '净资产',
  `SFSSGS` char(1) DEFAULT NULL COMMENT '是否上市公司',
  `SCJLXDGXRQ_DATE` varchar(32) DEFAULT NULL,
  `CYRYS` decimal(10,2) DEFAULT NULL COMMENT '从业人员数',
  `ZCD` varchar(400) DEFAULT NULL COMMENT '注册地',
  `ZCDHZQHDM` char(6) DEFAULT NULL COMMENT '注册地行政区划代码',
  `BGDZ` varchar(400) DEFAULT NULL COMMENT '办公地址',
  `BGDHZQHDM` char(6) DEFAULT NULL COMMENT '办公地行政区划代码',
  `JYZT` char(2) DEFAULT NULL COMMENT '经营状态',
  `CLRQ_DATE` varchar(32) DEFAULT NULL,
  `SSHY` char(3) DEFAULT NULL COMMENT '所属行业',
  `QYGM` char(4) DEFAULT NULL COMMENT '企业规模',
  `QYCZRJJCF` varchar(5) DEFAULT NULL COMMENT '企业出资人经济成分',
  `SXED_AMT` decimal(20,2) DEFAULT NULL COMMENT '授信额度',
  `YYED_AMT` decimal(20,2) DEFAULT NULL COMMENT '已用额度',
  `SFGLF` char(1) DEFAULT NULL COMMENT '是否关联方',
  `SJKZRLX` varchar(60) DEFAULT NULL COMMENT '实际控制人类型',
  `SJKZRZJLX` varchar(60) DEFAULT NULL COMMENT '实际控制人证件类型',
  `SJKZRZJDM` varchar(400) DEFAULT NULL COMMENT '实际控制人证件代码',
  `REMARKS` varchar(512) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` varchar(512) DEFAULT NULL COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本号',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝描述',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` varchar(32) DEFAULT NULL,
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` varchar(32) DEFAULT NULL,
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` varchar(32) DEFAULT NULL,
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL,
  `RSV2` varchar(180) DEFAULT NULL,
  `RSV3` varchar(180) DEFAULT NULL,
  `RSV4` varchar(180) DEFAULT NULL,
  `RSV5` varchar(180) DEFAULT NULL,
  `C_RSV1` varchar(180) DEFAULT NULL,
  `C_RSV2` varchar(180) DEFAULT NULL,
  `C_RSV3` varchar(180) DEFAULT NULL,
  `C_RSV4` varchar(180) DEFAULT NULL,
  `C_RSV5` varchar(180) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for gfdr_file_jrjgfz
-- ----------------------------
DROP TABLE IF EXISTS `gfdr_file_jrjgfz`;
CREATE TABLE `gfdr_file_jrjgfz` (
  `DATA_ID` varchar(64) NOT NULL DEFAULT '' COMMENT '数据ID',
  `DATA_DATE` varchar(32) DEFAULT NULL,
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '分行机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CJRQ_DATE` varchar(32) DEFAULT NULL,
  `JRJGMC` varchar(200) DEFAULT NULL COMMENT '金融机构名称',
  `JRJGDM` varchar(60) DEFAULT NULL COMMENT '金融机构代码',
  `JRJGBM` varchar(30) DEFAULT NULL COMMENT '金融机构编码',
  `NBJGH` varchar(30) DEFAULT NULL COMMENT '内部机构号',
  `JGJB` char(2) DEFAULT NULL COMMENT '机构级别',
  `ZSSJGLJGMC` varchar(200) DEFAULT NULL COMMENT '直属上级管理机构名称',
  `ZSSJGLJGJRJGBM` varchar(30) DEFAULT NULL COMMENT '直属上级管理机构金融机构编码',
  `ZSSJGLJGNBJGH` varchar(30) DEFAULT NULL COMMENT '直属上级管理机构内部机构号',
  `ZCDZ` varchar(400) DEFAULT NULL COMMENT '注册地址',
  `ZCDHZQHDM` char(6) DEFAULT NULL COMMENT '注册地行政区划代码',
  `BGDZ` varchar(400) DEFAULT NULL COMMENT '办公地址',
  `BGDHZQHDM` char(6) DEFAULT NULL COMMENT '办公地行政区划代码',
  `CLSJ_DATE` varchar(32) DEFAULT NULL,
  `YYZT` char(2) DEFAULT NULL COMMENT '营业状态',
  `REMARKS` varchar(512) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` varchar(512) DEFAULT NULL COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本号',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝描述',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` varchar(32) DEFAULT NULL,
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` varchar(32) DEFAULT NULL,
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` varchar(32) DEFAULT NULL,
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL,
  `RSV2` varchar(180) DEFAULT NULL,
  `RSV3` varchar(180) DEFAULT NULL,
  `RSV4` varchar(180) DEFAULT NULL,
  `RSV5` varchar(180) DEFAULT NULL,
  `C_RSV1` varchar(180) DEFAULT NULL,
  `C_RSV2` varchar(180) DEFAULT NULL,
  `C_RSV3` varchar(180) DEFAULT NULL,
  `C_RSV4` varchar(180) DEFAULT NULL,
  `C_RSV5` varchar(180) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for gp_bm_audit_log
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_audit_log`;
CREATE TABLE `gp_bm_audit_log` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `FUNC_ID` varchar(20) NOT NULL COMMENT '菜单号',
  `FUNC_NAME` varchar(60) DEFAULT NULL COMMENT '菜单名',
  `DEPART_ID` varchar(14) DEFAULT NULL COMMENT '部门号',
  `WORK_DATE` varchar(8) DEFAULT NULL COMMENT '工作日期',
  `TLRNO` varchar(20) DEFAULT NULL COMMENT '操作员号',
  `OP_TYPE` varchar(10) DEFAULT NULL COMMENT '操作类型',
  `VALUE_OBJECT_NAME` varchar(128) DEFAULT NULL COMMENT '数据对象名',
  `VALUE_BEFORE` longtext COMMENT '修改前的值',
  `VALUE_AFTER` longtext COMMENT '修改后的值',
  `VALUE_META` longtext COMMENT '操作数据元数据',
  `OP_TIME` varchar(20) DEFAULT NULL COMMENT '修改时间',
  `IP` varchar(32) DEFAULT NULL COMMENT '操作员IP',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='审计日志表';

-- ----------------------------
-- Table structure for gp_bm_batch_date
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_batch_date`;
CREATE TABLE `gp_bm_batch_date` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `BATCH_MODULE` varchar(32) DEFAULT NULL COMMENT '跑批模块',
  `BATCH_YEAR` decimal(8,0) DEFAULT NULL COMMENT '跑批日期',
  `BATCH_MONTH` varchar(8) DEFAULT NULL,
  `BATCH_DATE` varchar(8) DEFAULT NULL,
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='批量日期表';

-- ----------------------------
-- Table structure for gp_bm_batch_holiday
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_batch_holiday`;
CREATE TABLE `gp_bm_batch_holiday` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `BATCH_MODULE` varchar(32) DEFAULT NULL COMMENT '跑批模块',
  `YEAR` decimal(8,0) DEFAULT NULL COMMENT '年',
  `HOLIDAY_DEF` text,
  `LAST_UPD_TIME` char(14) DEFAULT NULL,
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='批量节假日表';

-- ----------------------------
-- Table structure for gp_bm_biz_log
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_biz_log`;
CREATE TABLE `gp_bm_biz_log` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `TXN_DATE` char(8) DEFAULT NULL COMMENT '交易日期',
  `TXN_START_TIME` char(14) DEFAULT NULL COMMENT '交易开始时间',
  `TXN_END_TIME` char(14) DEFAULT NULL COMMENT '交易结束时间',
  `TXN_RUN_TIME` char(14) DEFAULT NULL COMMENT '交易执行时间',
  `BRCODE` varchar(20) DEFAULT NULL COMMENT '交易机构',
  `OP_TYPE` varchar(20) DEFAULT NULL COMMENT '操作类型',
  `OPRCODE` varchar(20) DEFAULT NULL COMMENT '交易操作员',
  `IP_ADR` varchar(20) DEFAULT NULL COMMENT 'IP',
  `FUNCID` varchar(20) DEFAULT NULL COMMENT '交易码',
  `OPRTXNCD` varchar(100) DEFAULT NULL COMMENT '操作码',
  `TXN_BIZ_LOG1` text COMMENT '操作日志1',
  `TXN_BIZ_LOG2` text COMMENT '操作日志2',
  `TXN_STATUS` char(2) DEFAULT NULL COMMENT '交易状态',
  `TXN_FAIL_LOG` text COMMENT '失败信息',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注',
  `REF_ID` varchar(128) DEFAULT NULL COMMENT '业务关联ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='操作日志表';

-- ----------------------------
-- Table structure for gp_bm_bms_batch
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_bms_batch`;
CREATE TABLE `gp_bm_bms_batch` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `BATCH_NAME` varchar(60) DEFAULT NULL COMMENT '批量作业名称',
  `RUN_PLAN` varchar(18) DEFAULT NULL COMMENT '执行计划ID',
  `STATUS` char(1) DEFAULT NULL COMMENT '运行状态',
  `CFG_STATUS` char(1) DEFAULT NULL,
  `NEXT_TIME` char(14) DEFAULT NULL COMMENT '最近执行时间',
  `LAST_TIME` char(14) DEFAULT NULL,
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='批量定义表';

-- ----------------------------
-- Table structure for gp_bm_bms_batch_condition
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_bms_batch_condition`;
CREATE TABLE `gp_bm_bms_batch_condition` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `BATCH_NAME` varchar(60) DEFAULT NULL,
  `BATCH_ID` varchar(32) DEFAULT NULL,
  `BATCH_STATUS` char(1) DEFAULT NULL,
  `BATCH_FLAG` char(1) DEFAULT NULL,
  `BATCH_DATE` char(1) DEFAULT NULL,
  `BATH_DESC` varchar(128) DEFAULT NULL,
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='批量条件表';

-- ----------------------------
-- Table structure for gp_bm_bms_batch_log
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_bms_batch_log`;
CREATE TABLE `gp_bm_bms_batch_log` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `BATCH_ID` varchar(35) DEFAULT NULL,
  `STATUS` char(1) DEFAULT NULL,
  `C_CODE` char(2) DEFAULT NULL,
  `E_CODE` varchar(8) DEFAULT NULL,
  `E_MSG` text,
  `REMARKS` text,
  `START_TIME` char(14) DEFAULT NULL,
  `END_TIME` char(14) DEFAULT NULL,
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='批量日志表';

-- ----------------------------
-- Table structure for gp_bm_bms_batch_log_dtl
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_bms_batch_log_dtl`;
CREATE TABLE `gp_bm_bms_batch_log_dtl` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `BATCH_ID` varchar(35) DEFAULT NULL,
  `STATUS` char(1) DEFAULT NULL,
  `C_CODE` char(2) DEFAULT NULL,
  `E_CODE` varchar(8) DEFAULT NULL,
  `E_MSG` text,
  `REMARKS` text,
  `START_TIME` char(14) DEFAULT NULL,
  `END_TIME` char(14) DEFAULT NULL,
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='批量日志明细表';

-- ----------------------------
-- Table structure for gp_bm_bms_batch_method
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_bms_batch_method`;
CREATE TABLE `gp_bm_bms_batch_method` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `BATCH_NAME` varchar(60) DEFAULT NULL,
  `JOB_TYPE` varchar(60) DEFAULT NULL,
  `ARGS` text,
  `BATCH_SEQ` varchar(60) DEFAULT NULL,
  `BATCH_ID` varchar(32) DEFAULT NULL,
  `BATCH_STATUS` char(1) DEFAULT NULL,
  `BATCH_FLAG` char(1) DEFAULT NULL,
  `BATCH_DATE` char(1) DEFAULT NULL,
  `BATH_DESC` varchar(128) DEFAULT NULL,
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='批量函数表';

-- ----------------------------
-- Table structure for gp_bm_bms_ctl_cfg
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_bms_ctl_cfg`;
CREATE TABLE `gp_bm_bms_ctl_cfg` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `RUN_ORDER` decimal(8,0) DEFAULT NULL,
  `JOB_ID` varchar(64) DEFAULT NULL,
  `CONDITION` text,
  `WORKER_ID` char(18) DEFAULT NULL,
  `ARGS` text,
  `STATUS` char(1) DEFAULT NULL,
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注',
  `BATCH_ID` varchar(35) DEFAULT NULL,
  `NEXT_0` text,
  `NEXT_1` text,
  `NEXT_2` text,
  `NEXT_3` text,
  `NEXT_4` text,
  `JOB_TYPE` varchar(10) DEFAULT NULL COMMENT '任务类型',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='批量定义控制表';

-- ----------------------------
-- Table structure for gp_bm_bms_ctl_log
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_bms_ctl_log`;
CREATE TABLE `gp_bm_bms_ctl_log` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `BATCH_ID` varchar(35) DEFAULT NULL COMMENT '批量',
  `STATUS` char(1) DEFAULT NULL COMMENT '运行状态 0-未运行  1-运行中   2-运行完成',
  `C_CODE` char(2) DEFAULT NULL COMMENT '完成码',
  `E_CODE` varchar(8) DEFAULT NULL COMMENT '错误码',
  `E_MSG` text COMMENT '错误信息',
  `REMARKS` text COMMENT '备注',
  `START_TIME` char(14) DEFAULT NULL COMMENT '开始时间',
  `END_TIME` char(14) DEFAULT NULL COMMENT '结束时间',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='批量作业日志表';

-- ----------------------------
-- Table structure for gp_bm_bms_ctl_log_his
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_bms_ctl_log_his`;
CREATE TABLE `gp_bm_bms_ctl_log_his` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `BATCH_ID` varchar(35) DEFAULT NULL,
  `STATUS` char(1) DEFAULT NULL,
  `C_CODE` char(2) DEFAULT NULL,
  `E_CODE` varchar(8) DEFAULT NULL,
  `E_MSG` text,
  `REMARKS` text,
  `START_TIME` char(14) DEFAULT NULL,
  `END_TIME` char(14) DEFAULT NULL,
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='批量作业日志历史表';

-- ----------------------------
-- Table structure for gp_bm_bms_ctl_session
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_bms_ctl_session`;
CREATE TABLE `gp_bm_bms_ctl_session` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `SESSION_ID` varchar(35) DEFAULT NULL,
  `BATCH_ID` varchar(35) DEFAULT NULL,
  `JOB_ID` varchar(64) DEFAULT NULL,
  `P_JOB_ID` varchar(64) DEFAULT NULL,
  `P_C_CODE` char(2) DEFAULT NULL,
  `STATUS` char(1) DEFAULT NULL,
  `C_CODE` char(2) DEFAULT NULL,
  `E_CODE` varchar(8) DEFAULT NULL,
  `E_MSG` text,
  `START_TIME` char(14) DEFAULT NULL,
  `END_TIME` char(14) DEFAULT NULL,
  `NEXT_JOB_ID` varchar(35) DEFAULT NULL,
  `OUTPUT_1` text,
  `OUTPUT_2` text,
  `OUTPUT_3` text,
  `OUTPUT_4` text,
  `OUTPUT_5` text,
  `REMARKS` text,
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `RUN_ORDER` decimal(8,0) DEFAULT NULL COMMENT '0-未运行  1-运行中   2-运行完成',
  PRIMARY KEY (`DATA_ID`),
  KEY `IDX_GP_BM_BMS_CTL_SESSION_01` (`SESSION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='批量作业状态表';

-- ----------------------------
-- Table structure for gp_bm_bms_ctl_session_his
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_bms_ctl_session_his`;
CREATE TABLE `gp_bm_bms_ctl_session_his` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `SESSION_ID` varchar(35) DEFAULT NULL,
  `BATCH_ID` varchar(35) DEFAULT NULL,
  `JOB_ID` varchar(64) DEFAULT NULL,
  `P_JOB_ID` varchar(64) DEFAULT NULL,
  `P_C_CODE` char(2) DEFAULT NULL,
  `STATUS` char(1) DEFAULT NULL,
  `C_CODE` char(2) DEFAULT NULL,
  `E_CODE` varchar(8) DEFAULT NULL,
  `E_MSG` text,
  `START_TIME` char(14) DEFAULT NULL,
  `END_TIME` char(14) DEFAULT NULL,
  `NEXT_JOB_ID` varchar(35) DEFAULT NULL,
  `OUTPUT_1` text,
  `OUTPUT_2` text,
  `OUTPUT_3` text,
  `OUTPUT_4` text,
  `OUTPUT_5` text,
  `REMARKS` text,
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `RUN_ORDER` decimal(8,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='批量作业状态历史表';

-- ----------------------------
-- Table structure for gp_bm_bms_run_plan
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_bms_run_plan`;
CREATE TABLE `gp_bm_bms_run_plan` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `PLAN_ID` varchar(18) DEFAULT NULL COMMENT '执行计划ID',
  `BASE_DAY` char(3) DEFAULT NULL COMMENT '基准日期',
  `CALENDAR_NO` varchar(30) DEFAULT NULL COMMENT '工作日历',
  `OFFSET_D` decimal(65,30) DEFAULT NULL COMMENT '日期偏差值',
  `OFFSET_U` char(1) DEFAULT NULL COMMENT '日期偏差单位',
  `START_TIME` varchar(6) DEFAULT NULL COMMENT '开始时间',
  `END_TIME` varchar(6) DEFAULT NULL COMMENT '结束时间',
  `INTERAL` decimal(8,0) DEFAULT NULL COMMENT '执行时间间隔',
  `CFG_STATUS` char(1) DEFAULT NULL COMMENT '配置状态',
  `STATUS` char(1) DEFAULT NULL COMMENT '状态',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='执行计划表';

-- ----------------------------
-- Table structure for gp_bm_bms_worker_define
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_bms_worker_define`;
CREATE TABLE `gp_bm_bms_worker_define` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `NAME` varchar(60) DEFAULT NULL,
  `CLASS` text,
  `ARGS` text,
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='批量定义明细表';

-- ----------------------------
-- Table structure for gp_bm_branch
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_branch`;
CREATE TABLE `gp_bm_branch` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `BRCODE` varchar(20) DEFAULT NULL COMMENT '内部机构号',
  `BRNO` varchar(20) DEFAULT NULL COMMENT '机构代码',
  `BRNAME` varchar(60) DEFAULT NULL COMMENT '机构名称',
  `BRCLASS` char(1) DEFAULT NULL COMMENT '机构级别',
  `BRATTR` char(1) DEFAULT NULL COMMENT '机构属性',
  `BLN_BRANCH_CLASS` char(1) DEFAULT NULL,
  `BLN_BRANCH_BRCODE` varchar(20) DEFAULT NULL COMMENT '归属分行',
  `BLN_MANAGE_BRCODE` varchar(20) DEFAULT NULL COMMENT '账务机构',
  `BLN_UP_BRCODE` varchar(20) DEFAULT NULL COMMENT '上级机构',
  `LINKMAN` varchar(20) DEFAULT NULL COMMENT '联系人',
  `TELENO` varchar(20) DEFAULT NULL COMMENT '联系电话',
  `ADDRESS` varchar(100) DEFAULT NULL COMMENT '联系地址',
  `POSTNO` char(10) DEFAULT NULL COMMENT '邮编',
  `OTHER_AREA_FLAG` char(1) DEFAULT NULL COMMENT '异地行标识',
  `REGIONALISM` char(6) DEFAULT NULL COMMENT '行政区划代码',
  `FINANCE_CODE` char(14) DEFAULT NULL COMMENT '金融机构代码',
  `STATUS` char(1) DEFAULT NULL COMMENT '有效标识',
  `MISCFLGS` char(1) DEFAULT NULL COMMENT '扩展标识',
  `MISC` text COMMENT '扩展域',
  `LAST_UPD_TLR` char(8) DEFAULT NULL COMMENT '最后更新操作员',
  `LAST_UPD_FUNC` char(10) DEFAULT NULL COMMENT '最后修改交易码',
  `LAST_UPD_TIME` char(17) DEFAULT NULL COMMENT '最后更新时间',
  `ST` char(1) DEFAULT NULL COMMENT '有效标识',
  `IS_LOCK` char(1) DEFAULT NULL COMMENT '是否锁定',
  `IS_DEL` char(1) DEFAULT NULL COMMENT '是否已删除',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注',
  `C_CBRC_ID` varchar(14) DEFAULT NULL,
  `GPMS_NEXTACTION` varchar(8) DEFAULT NULL,
  `BUSINESS_LINE` text,
  PRIMARY KEY (`DATA_ID`),
  UNIQUE KEY `IDX_GP_BM_BRANCH_01` (`BRNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='机构信息表';

-- ----------------------------
-- Table structure for gp_bm_branch_pending
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_branch_pending`;
CREATE TABLE `gp_bm_branch_pending` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `BRCODE` varchar(20) DEFAULT NULL,
  `BRNO` varchar(20) DEFAULT NULL,
  `BRNAME` varchar(60) DEFAULT NULL,
  `BRCLASS` char(1) DEFAULT NULL,
  `BRATTR` char(1) DEFAULT NULL,
  `BLN_BRANCH_CLASS` char(1) DEFAULT NULL,
  `BLN_BRANCH_BRCODE` varchar(20) DEFAULT NULL,
  `BLN_MANAGE_BRCODE` varchar(20) DEFAULT NULL,
  `BLN_UP_BRCODE` varchar(20) DEFAULT NULL,
  `LINKMAN` varchar(20) DEFAULT NULL,
  `TELENO` varchar(20) DEFAULT NULL,
  `ADDRESS` varchar(100) DEFAULT NULL,
  `POSTNO` char(10) DEFAULT NULL,
  `OTHER_AREA_FLAG` char(1) DEFAULT NULL,
  `REGIONALISM` char(6) DEFAULT NULL,
  `FINANCE_CODE` char(14) DEFAULT NULL,
  `STATUS` char(1) DEFAULT NULL,
  `MISCFLGS` char(1) DEFAULT NULL,
  `MISC` text,
  `LAST_UPD_TLR` char(8) DEFAULT NULL,
  `LAST_UPD_FUNC` char(10) DEFAULT NULL,
  `LAST_UPD_TIME` char(17) DEFAULT NULL,
  `ST` char(1) DEFAULT NULL,
  `IS_LOCK` char(1) DEFAULT NULL,
  `IS_DEL` char(1) DEFAULT NULL,
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARKS` varchar(180) DEFAULT NULL,
  `C_CBRC_ID` varchar(8) DEFAULT NULL,
  `GPMS_NEXTACTION` varchar(8) DEFAULT NULL,
  `BUSINESS_LINE` text,
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='机构信息pending表';

-- ----------------------------
-- Table structure for gp_bm_business_line
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_business_line`;
CREATE TABLE `gp_bm_business_line` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `INQ_ORG_ID` char(24) DEFAULT NULL COMMENT '查询机构号',
  `INQ_GROUP_ID` char(24) DEFAULT NULL COMMENT '查询组号',
  `BUSINESS_LINE` varchar(32) DEFAULT NULL COMMENT '业务线',
  `BUSINESS_LINE_NAME` text COMMENT '业务线名称',
  `STATUS` varchar(1) DEFAULT NULL COMMENT '是否有效',
  `REMARKS` text COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `GPMS_NEXT_ACTION` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='业务条线表';

-- ----------------------------
-- Table structure for gp_bm_business_line_pending
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_business_line_pending`;
CREATE TABLE `gp_bm_business_line_pending` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `INQ_ORG_ID` char(24) DEFAULT NULL COMMENT '查询机构号',
  `INQ_GROUP_ID` char(24) DEFAULT NULL COMMENT '查询组号',
  `BUSINESS_LINE` varchar(32) DEFAULT NULL COMMENT '业务线',
  `BUSINESS_LINE_NAME` text COMMENT '业务线名称',
  `STATUS` varchar(1) DEFAULT NULL COMMENT '是否有效',
  `REMARKS` text COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `GPMS_NEXT_ACTION` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='业务条线pending表';

-- ----------------------------
-- Table structure for gp_bm_business_param
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_business_param`;
CREATE TABLE `gp_bm_business_param` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `PARAM_ID` varchar(30) DEFAULT NULL COMMENT '参数ID',
  `PARAM_GROUP_ID` varchar(20) DEFAULT NULL COMMENT '参数组号',
  `PARAM_START_DT` char(8) DEFAULT NULL COMMENT '有效期起',
  `PARAM_END_DT` char(8) DEFAULT NULL COMMENT '有效止日',
  `PARAM_NAME` text COMMENT '参数名称',
  `PARAM_VALUE` text NOT NULL COMMENT '参数值',
  `LOAD_TYPE` char(1) DEFAULT NULL COMMENT '加载方式',
  `IF_CANMODIFY` char(1) DEFAULT NULL COMMENT '是否可修改',
  `CATALOG` varchar(100) DEFAULT NULL COMMENT '参数分类',
  `LAST_UPD_TLR` char(8) DEFAULT NULL COMMENT '最后更新操作员',
  `LAST_UPD_FUNC` varchar(10) DEFAULT NULL COMMENT '最后修改交易码',
  `LAST_UPD_DATE` char(8) DEFAULT NULL COMMENT '最后更新时间',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='业务条线参数表';

-- ----------------------------
-- Table structure for gp_bm_check_config
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_check_config`;
CREATE TABLE `gp_bm_check_config` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `INQ_ORG_ID` char(24) DEFAULT NULL COMMENT '查询机构号',
  `INQ_GROUP_ID` char(24) DEFAULT NULL COMMENT '查询组号',
  `CK_GROUP` varchar(32) NOT NULL COMMENT '检验组',
  `CK_COLUMN` varchar(128) DEFAULT NULL COMMENT '校验列',
  `CK_DATATYPE` char(1) DEFAULT NULL COMMENT '数据类型',
  `CK_CHAR_SET` char(1) DEFAULT NULL COMMENT '数据字符类型',
  `CK_LENGTH` varchar(64) DEFAULT NULL COMMENT '数据长度',
  `CK_BORDER` varchar(128) DEFAULT NULL COMMENT '数据的上下线',
  `CK_NULL_TYPE` char(1) DEFAULT NULL COMMENT '必填项检查类型',
  `CK_NULL_FUN` text COMMENT '必填项检查方法',
  `CK_REG_EXPRESS` text COMMENT '正则表达式',
  `CK_VALIDITY_TYPE` char(1) DEFAULT NULL COMMENT '有效性检查类型',
  `CK_VALIDITY_FUN` text COMMENT '有效性检查方法',
  `CK_IF_CHAR_FLAG` char(1) DEFAULT NULL COMMENT '接口字符集校验',
  `CK_IF_CHAR_SET` char(1) DEFAULT NULL COMMENT '接口字符集类型',
  `CK_IF_LENGTH` varchar(64) DEFAULT NULL COMMENT '接口数据长度',
  `CK_RETURN_MESSAGE` text COMMENT '校验结果',
  `CK_COLUMN_XML` text COMMENT '返回信息',
  `CK_COLUMN_COMMENT` text COMMENT '返回信息',
  `CK_NULL_MESSAGE` text COMMENT '校验结果',
  `CK_VALIDITY_MESSAGE` text COMMENT '校验结果',
  `SYS_ID` varchar(32) DEFAULT NULL COMMENT '系统标识',
  `REMARKS` text COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `CK_COLUMN_BATCH` varchar(128) DEFAULT NULL,
  `CK_NULL_FUN_BATCH` text,
  `CK_VALIDITY_FUN_BATCH` text,
  `CHECK_RULE_NO` varchar(32) DEFAULT NULL COMMENT '人行校验编号',
  `CHECK_TYPE` varchar(32) DEFAULT NULL COMMENT '人行校验类型',
  `CK_TABLE_NAME_CN` varchar(128) DEFAULT NULL COMMENT '表名中文名',
  `CK_TABLE_NAME_EN` varchar(128) DEFAULT NULL COMMENT '表名英文名',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='校验表';

-- ----------------------------
-- Table structure for gp_bm_chg_org_cfg
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_chg_org_cfg`;
CREATE TABLE `gp_bm_chg_org_cfg` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `USER_ID` varchar(32) DEFAULT NULL COMMENT '用户ID',
  `CHG_ORG_ID` varchar(32) DEFAULT NULL COMMENT '机构ID',
  `REMARK` text COMMENT '备注',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `GPMS_NEXTACTION` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='机构切换配置表';

-- ----------------------------
-- Table structure for gp_bm_chg_org_cfg_pending
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_chg_org_cfg_pending`;
CREATE TABLE `gp_bm_chg_org_cfg_pending` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `USER_ID` varchar(32) DEFAULT NULL COMMENT '用户ID',
  `CHG_ORG_ID` varchar(32) DEFAULT NULL COMMENT '机构ID',
  `REMARK` text COMMENT '备注',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `GPMS_NEXTACTION` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='机构切换配置pending表';

-- ----------------------------
-- Table structure for gp_bm_code_list
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_code_list`;
CREATE TABLE `gp_bm_code_list` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CODE_SCHEMA` varchar(30) DEFAULT NULL COMMENT '编码集',
  `CODE_ITEM` varchar(30) DEFAULT NULL COMMENT '编码项目',
  `CODE_VALUE` varchar(60) DEFAULT NULL COMMENT '数据编码',
  `CODE_NAME` varchar(180) DEFAULT NULL COMMENT '数据编码名称',
  `P_CODE_VALUE` varchar(60) DEFAULT NULL COMMENT '父级数据编码',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='数据编码列表';

-- ----------------------------
-- Table structure for gp_bm_code_schema
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_code_schema`;
CREATE TABLE `gp_bm_code_schema` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CODE_SCHEMA` varchar(30) DEFAULT NULL COMMENT '编码方案',
  `CODE_SCHEMA_NAME` varchar(180) DEFAULT NULL COMMENT '方案名称',
  `SCHEMA_TYPE` varchar(1) DEFAULT NULL COMMENT '方案类型 1-精细控制模式；2-简化控制模式',
  `SQL_STRING` text COMMENT '权限串 sql语句',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='数据编码方案表';

-- ----------------------------
-- Table structure for gp_bm_code_schema_item
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_code_schema_item`;
CREATE TABLE `gp_bm_code_schema_item` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CODE_SCHEMA` varchar(30) DEFAULT NULL COMMENT '编码方案',
  `CODE_ITEM` varchar(30) DEFAULT NULL COMMENT '编码项',
  `CODE_ITEM_NAME` varchar(180) DEFAULT NULL COMMENT '编码项名称',
  `P_CODE_ITEM` varchar(30) DEFAULT NULL COMMENT '父级数据编码',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='数据编码方案编码项定义表';

-- ----------------------------
-- Table structure for gp_bm_data_dic
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_data_dic`;
CREATE TABLE `gp_bm_data_dic` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `DATA_TYPE_NO` decimal(10,0) NOT NULL COMMENT '数据类型编号',
  `DATA_NO` varchar(180) NOT NULL COMMENT '数据编号',
  `DATA_TYPE_NAME` varchar(80) NOT NULL COMMENT '数据类型名称',
  `DATA_NO_LEN` decimal(6,0) DEFAULT NULL COMMENT '数据编号长度',
  `DATA_NAME` text NOT NULL COMMENT '数据内容',
  `LIMIT_FLAG` char(1) DEFAULT NULL COMMENT '是否有上下限标志',
  `HIGH_LIMIT` varchar(20) DEFAULT NULL COMMENT '上限',
  `LOW_LIMIT` varchar(20) DEFAULT NULL COMMENT '下限',
  `EFFECT_DATE` char(8) DEFAULT NULL COMMENT '生效日期',
  `EXPIRE_DATE` char(8) DEFAULT NULL COMMENT '失效日期',
  `MISCFLGS` varchar(20) DEFAULT NULL COMMENT '扩展标志位',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`DATA_ID`),
  KEY `IDX_GP_BM_DATA_DIC_01` (`DATA_NO`,`DATA_TYPE_NO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='数据字典表';

-- ----------------------------
-- Table structure for gp_bm_data_rules
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_data_rules`;
CREATE TABLE `gp_bm_data_rules` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `QUERY_ID` text,
  `OPERATION_ID` char(14) DEFAULT NULL,
  `COLUMN_NAME` char(14) DEFAULT NULL,
  `DATA_TYPE` varchar(20) DEFAULT NULL,
  `VAL_KIND` char(2) DEFAULT NULL,
  `VAL_TYPE` varchar(4) DEFAULT NULL,
  `IS_NULL` char(1) DEFAULT NULL,
  `MAX_VALUE` varchar(255) DEFAULT NULL,
  `MIN_VALUE` varchar(255) DEFAULT NULL,
  `MAX_LENGTH` varchar(255) DEFAULT NULL,
  `MIN_LENGTH` varchar(255) DEFAULT NULL,
  `REG_EXPRESS` varchar(255) DEFAULT NULL,
  `EXPRESS` varchar(255) DEFAULT NULL,
  `VALIDITY_MESSAGE` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='数据校验表';

-- ----------------------------
-- Table structure for gp_bm_depart
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_depart`;
CREATE TABLE `gp_bm_depart` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `INQ_ORG_ID` char(24) DEFAULT NULL COMMENT '查询机构号',
  `INQ_GROUP_ID` char(24) DEFAULT NULL COMMENT '查询组号',
  `DEPART` varchar(32) DEFAULT NULL COMMENT '部门编号',
  `DEPART_NAME` varchar(180) DEFAULT NULL COMMENT '部门名称',
  `P_DEPART` varchar(32) DEFAULT NULL COMMENT '上级部门编号',
  `STATUS` varchar(1) DEFAULT NULL COMMENT '是否有效',
  `REMARKS` text COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `GPMS_NEXT_ACTION` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for gp_bm_depart_next_action
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_depart_next_action`;
CREATE TABLE `gp_bm_depart_next_action` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `INQ_ORG_ID` char(24) DEFAULT NULL COMMENT '查询机构号',
  `INQ_GROUP_ID` char(24) DEFAULT NULL COMMENT '查询组号',
  `O_DATA_ID` varchar(32) DEFAULT NULL COMMENT '数据iD',
  `FUNCID` varchar(50) DEFAULT NULL COMMENT '菜单名',
  `DEPART` varchar(30) DEFAULT NULL COMMENT '部门编号',
  `GROUP_NUM` varchar(3) DEFAULT NULL COMMENT '组别号',
  `REMARKS` text COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for gp_bm_depart_pending
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_depart_pending`;
CREATE TABLE `gp_bm_depart_pending` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `INQ_ORG_ID` char(24) DEFAULT NULL COMMENT '查询机构号',
  `INQ_GROUP_ID` char(24) DEFAULT NULL COMMENT '查询组号',
  `DEPART` varchar(32) DEFAULT NULL COMMENT '部门编号',
  `DEPART_NAME` varchar(180) DEFAULT NULL COMMENT '部门名称',
  `P_DEPART` varchar(32) DEFAULT NULL COMMENT '上级部门编号',
  `STATUS` varchar(1) DEFAULT NULL COMMENT '是否有效',
  `REMARKS` text COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `GPMS_NEXT_ACTION` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for gp_bm_email_log
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_email_log`;
CREATE TABLE `gp_bm_email_log` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `SEND_DATE` char(8) DEFAULT NULL,
  `SEND_TIME` char(14) DEFAULT NULL,
  `SEND_EMAIL` varchar(64) DEFAULT NULL,
  `RECE_EMAIL` varchar(64) DEFAULT NULL,
  `RECE_TLR_NO` varchar(64) DEFAULT NULL,
  `TITLE` varchar(200) DEFAULT NULL,
  `MESS` text,
  `STATUS` char(1) DEFAULT NULL,
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  UNIQUE KEY `SYS_C00245249` (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='邮件日志表';

-- ----------------------------
-- Table structure for gp_bm_file_export_tsk_inf
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_file_export_tsk_inf`;
CREATE TABLE `gp_bm_file_export_tsk_inf` (
  `TSK_ID` char(36) NOT NULL,
  `TSK_NM` varchar(50) DEFAULT NULL,
  `TSK_START_TMS` char(14) DEFAULT NULL,
  `TSK_START_OP` varchar(40) DEFAULT NULL,
  `TSK_DESC` varchar(200) DEFAULT NULL,
  `TSK_PARAM1` text,
  `TSK_PARAM2` text,
  `TSK_OWNER` varchar(40) DEFAULT NULL,
  `TSK_END_TMS` char(14) DEFAULT NULL,
  `TSK_RUN_CLASS` char(2) DEFAULT NULL,
  `EXP_FILE_NM` varchar(128) DEFAULT NULL,
  `EXP_RCD_NUM` decimal(65,30) DEFAULT NULL,
  `EXP_RCD_SUM_NUM` decimal(65,30) DEFAULT NULL,
  `EXP_FILE_SIZE` decimal(65,30) DEFAULT NULL,
  `TSK_STAT` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='文件批量导出任务表';

-- ----------------------------
-- Table structure for gp_bm_function
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_function`;
CREATE TABLE `gp_bm_function` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `FUNCID` varchar(32) DEFAULT NULL,
  `FUNCNAME` text COMMENT '权限名/菜单名',
  `PAGEPATH` varchar(100) DEFAULT NULL COMMENT '访问路径(相对路径)',
  `LOCATION` decimal(65,0) DEFAULT NULL COMMENT '1－在左侧树菜单；2－在上面导航条',
  `ISDIRECTORY` decimal(65,0) DEFAULT NULL COMMENT '目录节点：1是；0否',
  `LASTDIRECTORY` varchar(32) DEFAULT NULL COMMENT '指定上级FUNCID，0为根节点',
  `SHOWSEQ` decimal(65,0) DEFAULT NULL,
  `SYS_NUM` varchar(20) DEFAULT NULL,
  `FUNC_CLASS` char(1) DEFAULT NULL COMMENT '目前不使用',
  `FUNC_TYPE` char(1) DEFAULT NULL COMMENT '目前不使用',
  `WORKFLOW_FLAG` char(1) DEFAULT NULL COMMENT '目前不使用',
  `UP_FUNC_CODE` char(10) DEFAULT NULL COMMENT '目前不使用',
  `FUNC_DESC` varchar(60) DEFAULT NULL,
  `STATUS` char(1) DEFAULT NULL COMMENT '1有效，0无效',
  `EFFECT_DATE` char(8) DEFAULT NULL,
  `EXPIRE_DATE` char(8) DEFAULT NULL,
  `TIMESTAMPS` varchar(100) DEFAULT NULL,
  `MISCFLGS` char(20) DEFAULT NULL,
  `MISC` text,
  `ICON_CLS` varchar(50) DEFAULT NULL COMMENT '引用的图标名称',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARKS` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='菜单权限表';

-- ----------------------------
-- Table structure for gp_bm_function_table
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_function_table`;
CREATE TABLE `gp_bm_function_table` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `FUNCID` varchar(20) DEFAULT NULL,
  `STATUS` char(1) DEFAULT NULL,
  `TIMESTAMPS` varchar(100) DEFAULT NULL,
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARKS` varchar(180) DEFAULT NULL,
  `TABLENAME` varchar(60) DEFAULT NULL,
  `FUNCNAME` varchar(180) DEFAULT NULL,
  UNIQUE KEY `SYS_C00244964` (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='菜单数据库表映射表';

-- ----------------------------
-- Table structure for gp_bm_global_info
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_global_info`;
CREATE TABLE `gp_bm_global_info` (
  `ID` decimal(65,30) NOT NULL,
  `SYSTEM_NAME` varchar(20) DEFAULT NULL,
  `TBSDY` char(8) DEFAULT NULL,
  `BHDATE` char(8) DEFAULT NULL,
  `LBHDATE` char(8) DEFAULT NULL,
  `STATUS` char(1) DEFAULT NULL,
  `SYSTEM_TYPE` char(2) DEFAULT NULL,
  `MISCFLGS` varchar(20) DEFAULT NULL,
  `DATA_HASH` varchar(32) DEFAULT NULL COMMENT '记录Hash值',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='全局信息表';

-- ----------------------------
-- Table structure for gp_bm_gno_chl
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_gno_chl`;
CREATE TABLE `gp_bm_gno_chl` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CHL_ID` varchar(32) DEFAULT NULL COMMENT '渠道ID',
  `CHL_TYPE` char(1) DEFAULT NULL COMMENT '渠道类型',
  `SERVICE_ID` varchar(32) DEFAULT NULL COMMENT '渠道服务',
  `RADDR` varchar(32) DEFAULT NULL COMMENT '目标地址',
  `STATUS` varchar(2) DEFAULT NULL COMMENT '状态',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '说明',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='通知渠道';

-- ----------------------------
-- Table structure for gp_bm_gno_dic
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_gno_dic`;
CREATE TABLE `gp_bm_gno_dic` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `DIC_ID` varchar(64) DEFAULT NULL COMMENT '数据类型',
  `DATA_VALUE` varchar(64) DEFAULT NULL COMMENT '数据值',
  `DATA_DESC` text COMMENT '值描述',
  `DATA_TYPE` varchar(64) DEFAULT NULL COMMENT '数据类型',
  `IDX` decimal(8,0) DEFAULT NULL COMMENT '数据排序',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '类型说明',
  `SYSTEM` varchar(128) DEFAULT NULL COMMENT '所属系统',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='数据字典表';

-- ----------------------------
-- Table structure for gp_bm_gno_field_dic
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_gno_field_dic`;
CREATE TABLE `gp_bm_gno_field_dic` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `FIELD_NAME` varchar(60) DEFAULT NULL COMMENT '字段名字',
  `FIELD_ID` varchar(20) DEFAULT NULL COMMENT '字段标识',
  `FIELD_TYPE` varchar(20) DEFAULT NULL COMMENT '字段类型（默认）',
  `FIELD_LEN` varchar(8) DEFAULT NULL COMMENT '字段长度（默认）',
  `FIELD_TBL_SIZE` varchar(8) DEFAULT NULL COMMENT '字段表长度（默认）',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='表字段名称字典';

-- ----------------------------
-- Table structure for gp_bm_gno_msg
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_gno_msg`;
CREATE TABLE `gp_bm_gno_msg` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `MSG_ID` varchar(64) DEFAULT NULL COMMENT '数据ID',
  `SEQ_NO` varchar(32) DEFAULT NULL COMMENT '消息序号',
  `MSG_SENDER` varchar(32) DEFAULT NULL COMMENT '数据发送者',
  `MSG_CODE` varchar(32) DEFAULT NULL COMMENT '消息编码',
  `MSG_TYPE` varchar(32) DEFAULT NULL COMMENT '消息类型',
  `MSG_FMT` varchar(20) DEFAULT NULL COMMENT '报文格式',
  `SEND_DATE` char(8) DEFAULT NULL COMMENT '消息发送日期',
  `SEND_NODE` varchar(32) DEFAULT NULL COMMENT '发送节点',
  `REF_ID` varchar(32) DEFAULT NULL COMMENT '关联ID',
  `MSG_FILE` text COMMENT '消息文件',
  `DATA_FILE` text COMMENT '数据文件',
  `TOPIC` varchar(32) DEFAULT NULL COMMENT '消息主题',
  `TPL_ID` varchar(32) DEFAULT NULL COMMENT '模板ID',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='通知消息';

-- ----------------------------
-- Table structure for gp_bm_gno_q
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_gno_q`;
CREATE TABLE `gp_bm_gno_q` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `USER_ID` varchar(32) DEFAULT NULL COMMENT '用户ID',
  `MSG_ID` varchar(64) DEFAULT NULL COMMENT '消息ID',
  `CHL_ID` varchar(32) DEFAULT NULL COMMENT '渠道ID',
  `STATUS` char(2) DEFAULT NULL COMMENT '状态',
  `MSG_TYPE` varchar(10) DEFAULT NULL COMMENT '消息类型',
  `MSG_FMT` varchar(10) DEFAULT NULL COMMENT '消息格式',
  `MSG_TITLE` varchar(180) DEFAULT NULL COMMENT '消息标题',
  `TRY_NUM` decimal(8,0) DEFAULT NULL COMMENT '重试次数',
  `MSG_STATUS` char(2) DEFAULT NULL COMMENT '阅读状态',
  `TO_ADDR` text COMMENT '接收目的地址',
  `CC_ADDR` text COMMENT '抄送地址',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `MSG_CONTENT` longtext,
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='通知队列';

-- ----------------------------
-- Table structure for gp_bm_gno_sub
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_gno_sub`;
CREATE TABLE `gp_bm_gno_sub` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `ROLE_ID` varchar(32) DEFAULT NULL COMMENT '角色ID',
  `TOPIC` varchar(32) DEFAULT NULL COMMENT '消息主题',
  `CHL_ID` varchar(32) DEFAULT NULL COMMENT '渠道',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '说明',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='消息订阅';

-- ----------------------------
-- Table structure for gp_bm_gno_topic
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_gno_topic`;
CREATE TABLE `gp_bm_gno_topic` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `TOPIC` varchar(32) DEFAULT NULL COMMENT '消息主题',
  `TPL_ID` varchar(32) DEFAULT NULL COMMENT '模板ID',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '说明',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='消息主题';

-- ----------------------------
-- Table structure for gp_bm_gno_tpl
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_gno_tpl`;
CREATE TABLE `gp_bm_gno_tpl` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `TPL_ID` varchar(32) DEFAULT NULL COMMENT '模板ID',
  `TPL_LANG` varchar(8) DEFAULT NULL COMMENT '模板语言',
  `CHL_ID` varchar(32) DEFAULT NULL COMMENT '渠道',
  `MSG_FMT` varchar(32) DEFAULT NULL COMMENT '报文格式',
  `MSG_TITLE` varchar(180) DEFAULT NULL COMMENT '消息标题',
  `TPL_DATA` text COMMENT '模板数据',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='通知消息模板';

-- ----------------------------
-- Table structure for gp_bm_group
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_group`;
CREATE TABLE `gp_bm_group` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `DEPART_ID` varchar(32) DEFAULT NULL COMMENT '机构id',
  `GROUP_NAME` varchar(128) DEFAULT NULL COMMENT '部门名称',
  `PGROUP_ID` varchar(32) DEFAULT NULL,
  `GROUP_CONTACT` varchar(64) DEFAULT NULL,
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='部门信息表';

-- ----------------------------
-- Table structure for gp_bm_group_cfg
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_group_cfg`;
CREATE TABLE `gp_bm_group_cfg` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `INQ_ORG_ID` char(24) DEFAULT NULL COMMENT '查询机构号',
  `INQ_GROUP_ID` char(24) DEFAULT NULL COMMENT '查询组号',
  `FUNCID` varchar(50) DEFAULT NULL COMMENT '菜单名',
  `DEPART` varchar(30) DEFAULT NULL COMMENT '部门编号',
  `GROUP_NUM` varchar(3) DEFAULT NULL COMMENT '组别号',
  `GROUP_NAME` varchar(120) DEFAULT NULL COMMENT '组别名',
  `REMARKS` text COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for gp_bm_holiday
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_holiday`;
CREATE TABLE `gp_bm_holiday` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `YEAR` decimal(8,0) DEFAULT NULL COMMENT '年',
  `HOLIDAY_DEF` text,
  `LAST_UPD_TIME` char(14) DEFAULT NULL,
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='工作日历表';

-- ----------------------------
-- Table structure for gp_bm_id_fielddata
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_id_fielddata`;
CREATE TABLE `gp_bm_id_fielddata` (
  `GUID` varchar(32) NOT NULL COMMENT 'UUID',
  `FIELD_NAME` varchar(40) NOT NULL,
  `UMW_EXPRESSION` text NOT NULL,
  `U_DATATYPE` varchar(1) DEFAULT NULL,
  `UPDATE_WAY` varchar(1) DEFAULT NULL,
  `UNIQUEKEY_FLAG` varchar(1) DEFAULT NULL,
  `UPDATE_FLAG` varchar(1) DEFAULT NULL,
  `FILTER_FLAG` varchar(1) DEFAULT NULL,
  `FILLER1` varchar(255) DEFAULT NULL,
  `FILLER2` varchar(255) DEFAULT NULL,
  `FILLER3` varchar(255) DEFAULT NULL,
  `PGUID` varchar(32) DEFAULT NULL,
  `LIMIT_FLAG` varchar(1) DEFAULT NULL,
  `BUSINESSKEY_FLAG` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`GUID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='数据导入配置表';

-- ----------------------------
-- Table structure for gp_bm_id_filedata
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_id_filedata`;
CREATE TABLE `gp_bm_id_filedata` (
  `GUID` varchar(32) NOT NULL COMMENT 'UUID',
  `DEPART_ID` varchar(32) NOT NULL,
  `FILE_NAME` varchar(128) NOT NULL,
  `TABLE_NAME` varchar(128) NOT NULL,
  `BATCH_NO` decimal(65,0) NOT NULL,
  `FILE_OWNER` varchar(32) NOT NULL,
  `FORMAT_TYPE` varchar(1) NOT NULL,
  `LIST_SEPARATOR` varchar(10) DEFAULT NULL,
  `SEQUENCE_NO` decimal(65,0) DEFAULT NULL,
  `IMPORT_TIME` varchar(2) DEFAULT NULL,
  `KEY_FLAG` varchar(1) DEFAULT NULL,
  `START_ROW` decimal(65,0) DEFAULT NULL,
  `START_COLUMN` decimal(65,0) DEFAULT NULL,
  `ENDROW_FLAG` varchar(1) DEFAULT NULL,
  `END_COLUMN` decimal(65,0) DEFAULT NULL,
  `SHEET_NUM` decimal(65,0) DEFAULT NULL,
  `MAIN_FLAG` varchar(2) DEFAULT NULL,
  `FUID` varchar(32) DEFAULT NULL,
  `COMMENTS` varchar(255) DEFAULT NULL,
  `FILLER1` varchar(255) DEFAULT NULL,
  `FILLER2` varchar(255) DEFAULT NULL,
  `FILLER3` varchar(255) DEFAULT NULL,
  `FILENAME_FORMAT` varchar(200) DEFAULT NULL,
  `AUTOIMPORTFLAG` varchar(2) DEFAULT NULL,
  `FUNCNAME` varchar(60) DEFAULT NULL,
  `FUNCID` varchar(60) DEFAULT NULL,
  `CHECK_TABLE` varchar(20) DEFAULT NULL,
  `IMPORT_TYPE` varchar(2) DEFAULT NULL,
  `JOB_TYPE` varchar(2) DEFAULT NULL,
  `ARGS` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`GUID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='数据导入表';

-- ----------------------------
-- Table structure for gp_bm_id_filterdata
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_id_filterdata`;
CREATE TABLE `gp_bm_id_filterdata` (
  `GUID` varchar(32) NOT NULL,
  `FIELD_NAME` varchar(128) NOT NULL,
  `DATA_TYPE` varchar(1) DEFAULT NULL,
  `FILTER_EXPRESSION` text,
  `FILLER1` varchar(255) DEFAULT NULL,
  `FILLER2` varchar(255) DEFAULT NULL,
  `FILLER3` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='导入数据过滤表';

-- ----------------------------
-- Table structure for gp_bm_id_functiondata
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_id_functiondata`;
CREATE TABLE `gp_bm_id_functiondata` (
  `FUNC_NAME` varchar(128) NOT NULL,
  `FUNC_FLAG` varchar(1) NOT NULL,
  `FUNC_DESC` text NOT NULL,
  `FILLER1` varchar(255) DEFAULT NULL,
  `FILLER2` varchar(255) DEFAULT NULL,
  `FILLER3` varchar(255) DEFAULT NULL,
  `DATA_HASH` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`FUNC_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='导入函数信息表';

-- ----------------------------
-- Table structure for gp_bm_id_importlog
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_id_importlog`;
CREATE TABLE `gp_bm_id_importlog` (
  `GUID` varchar(32) NOT NULL,
  `WORK_DATE` char(8) NOT NULL,
  `FILE_OWNER` varchar(32) NOT NULL,
  `SERICAL_NO` decimal(65,30) NOT NULL,
  `IMPORT_STATUS` varchar(1) NOT NULL,
  `ERROR_NUMBER` decimal(65,30) DEFAULT NULL,
  `ERROR_MESSAGE` text,
  `TOTAL_ROWS` decimal(65,30) DEFAULT NULL,
  `CORRECT_ROWS` decimal(65,30) DEFAULT NULL,
  `FILTER_ROWS` decimal(65,30) DEFAULT NULL,
  `BEGIN_TIME` char(14) DEFAULT NULL,
  `ERR_FILENAMEPATH` text,
  `ERR_FILENAME` varchar(128) DEFAULT NULL,
  `MOD_FLG` varchar(2) DEFAULT NULL,
  `END_TIME` varchar(20) DEFAULT NULL,
  `FILE_NAME` text,
  `FILLER2` varchar(255) DEFAULT NULL,
  `FILLER3` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='导入日志表';

-- ----------------------------
-- Table structure for gp_bm_id_importlogdtl
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_id_importlogdtl`;
CREATE TABLE `gp_bm_id_importlogdtl` (
  `GUID` varchar(32) NOT NULL,
  `WORK_DATE` varchar(8) NOT NULL,
  `FILE_OWNER` varchar(32) NOT NULL,
  `SERICAL_NO` decimal(65,30) NOT NULL,
  `LINE_NO` decimal(65,30) NOT NULL,
  `POS_NO` varchar(32) DEFAULT NULL,
  `ERROR_MESSAGE` text,
  `MOD_FLG` varchar(2) DEFAULT NULL,
  `BEGIN_TIME` varchar(20) DEFAULT NULL,
  `END_TIME` varchar(20) DEFAULT NULL,
  `ERR_FILENAME` varchar(128) DEFAULT NULL,
  `FILE_NAME` varchar(255) DEFAULT NULL,
  `FILLER2` varchar(255) DEFAULT NULL,
  `FILLER3` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='导入日志明细表';

-- ----------------------------
-- Table structure for gp_bm_id_uploadlog
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_id_uploadlog`;
CREATE TABLE `gp_bm_id_uploadlog` (
  `UPLOAD_GUID` varchar(32) NOT NULL COMMENT 'UUID',
  `WORK_DATE` varchar(8) DEFAULT NULL,
  `FILE_NAME` text,
  `TARGET_PATH` varchar(200) DEFAULT NULL,
  `SND_IP` varchar(20) DEFAULT NULL,
  `REC_IP` varchar(20) DEFAULT NULL,
  `UPLOAD_TIME` varchar(14) DEFAULT NULL,
  `UPLOADER` varchar(64) DEFAULT NULL,
  `FILLER1` varchar(60) DEFAULT NULL,
  `FILLER2` varchar(60) DEFAULT NULL,
  `FILLER3` varchar(60) DEFAULT NULL,
  `UPLOAD_ORG_ID` varchar(60) DEFAULT NULL,
  `STORE_NAME` varchar(80) DEFAULT NULL,
  `CJRQ_DATE` char(8) DEFAULT NULL,
  `REPORT_CODE` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='上传日志表';

-- ----------------------------
-- Table structure for gp_bm_id_xmldata
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_id_xmldata`;
CREATE TABLE `gp_bm_id_xmldata` (
  `PUID` varchar(32) NOT NULL,
  `FUID` varchar(32) NOT NULL,
  `GUID` varchar(32) NOT NULL,
  `NODES_NAME` varchar(128) NOT NULL,
  `NODE_ORDER` varchar(2) NOT NULL,
  `NODE_XPATH` text NOT NULL,
  `NODE_PROPERTY` varchar(1) NOT NULL,
  `NODE_GETVAL` varchar(1) NOT NULL,
  `NODE_RTVAL` varchar(1) DEFAULT NULL,
  `FILLER1` varchar(255) DEFAULT NULL,
  `FILLER2` varchar(255) DEFAULT NULL,
  `FILLER3` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='XML配置表';

-- ----------------------------
-- Table structure for gp_bm_inq_cfg
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_inq_cfg`;
CREATE TABLE `gp_bm_inq_cfg` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARK` text COMMENT '备注',
  `SQL_ID` varchar(64) DEFAULT NULL,
  `SQL_STRING` text,
  `DETAIL_SQL_STRING` text,
  `SYSTEM` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`),
  UNIQUE KEY `UNIQUE_INQ_CFG` (`SQL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='通用查询配置表';

-- ----------------------------
-- Table structure for gp_bm_job
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_job`;
CREATE TABLE `gp_bm_job` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `JOB_GROUP` text,
  `JOB_ID` text,
  `TYPE` varchar(20) DEFAULT NULL,
  `EXPRESSION` text,
  `DATA` text,
  `IS_TRANSACTIONAL` char(1) DEFAULT NULL,
  `IS_CONCURRENT` char(1) DEFAULT NULL,
  `DESCRIPTION` text,
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARKS` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='定时任务表';

-- ----------------------------
-- Table structure for gp_bm_job_log
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_job_log`;
CREATE TABLE `gp_bm_job_log` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `JOB_GROUP` text,
  `JOB_ID` text,
  `START_TIME` char(14) DEFAULT NULL,
  `END_TIME` char(14) DEFAULT NULL,
  `STATUS` varchar(20) DEFAULT NULL,
  `MESSAGE` text,
  `STACK_TRACE` text,
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='定时任务日志表';

-- ----------------------------
-- Table structure for gp_bm_job_schedule
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_job_schedule`;
CREATE TABLE `gp_bm_job_schedule` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `JOB_GROUP` text,
  `JOB_ID` text,
  `DESCRIPTION` text,
  `STATUS` varchar(20) DEFAULT NULL COMMENT 'RUNNING，STOP',
  `RUN_SECOND` varchar(255) DEFAULT NULL,
  `RUN_MINUTE` varchar(255) DEFAULT NULL,
  `RUN_HOUR` varchar(255) DEFAULT NULL,
  `RUN_DAY_IN_MONTH` varchar(255) DEFAULT NULL,
  `RUN_MONTH` varchar(255) DEFAULT NULL,
  `RUN_DAY_IN_WEEK` varchar(255) DEFAULT NULL,
  `RUN_YEAR` varchar(255) DEFAULT NULL,
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARKS` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='定时任务计划表';

-- ----------------------------
-- Table structure for gp_bm_login_log
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_login_log`;
CREATE TABLE `gp_bm_login_log` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注',
  `TLR_NO` varchar(20) DEFAULT NULL COMMENT '操作员编号',
  `BR_NO` varchar(20) DEFAULT NULL COMMENT '部门编号',
  `LOGIN_SUC_TM` char(14) DEFAULT NULL COMMENT '登录时间',
  `LOGIN_OUT_TM` char(14) DEFAULT NULL COMMENT '退出时间',
  `LOGIN_FAIL_TM` char(14) DEFAULT NULL COMMENT '登录失败时间',
  `LOGIN_ADDR` varchar(20) DEFAULT NULL COMMENT 'IP',
  `LOGIN_REMARK` text COMMENT '登录信息',
  `SESSION_ID` varchar(32) DEFAULT NULL,
  `CRT_TM` char(14) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='操作员登陆日志表';

-- ----------------------------
-- Table structure for gp_bm_mon_config
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_mon_config`;
CREATE TABLE `gp_bm_mon_config` (
  `MONITOR_NAME` text NOT NULL,
  `MONITOR_BEAN` text,
  `TOPIC` varchar(32) DEFAULT NULL,
  `STATUS` varchar(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='监控配置表';

-- ----------------------------
-- Table structure for gp_bm_msg_sub_group
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_msg_sub_group`;
CREATE TABLE `gp_bm_msg_sub_group` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `INQ_ORG_ID` char(24) DEFAULT NULL COMMENT '查询机构号',
  `INQ_GROUP_ID` char(24) DEFAULT NULL COMMENT '查询组号',
  `SUB_GROUP_ID` varchar(32) DEFAULT NULL COMMENT '订阅用户/邮件组ID',
  `SUB_GROUP_NAME` text COMMENT '订阅用户/邮件组姓名',
  `SUB_TYPE` varchar(2) DEFAULT NULL COMMENT '订阅组类型',
  `TOPIC` varchar(32) DEFAULT NULL COMMENT '消息主题',
  `CHL_ID` varchar(32) DEFAULT NULL COMMENT '渠道',
  `REMARKS` text COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for gp_bm_msg_sub_group_dtl
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_msg_sub_group_dtl`;
CREATE TABLE `gp_bm_msg_sub_group_dtl` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `INQ_ORG_ID` char(24) DEFAULT NULL COMMENT '查询机构号',
  `INQ_GROUP_ID` char(24) DEFAULT NULL COMMENT '查询组号',
  `SUB_GROUP_ID` varchar(32) DEFAULT NULL COMMENT '订阅用户/邮件组ID',
  `TLRNO` varchar(20) DEFAULT NULL COMMENT '用户名',
  `EMAIL_ADDRESS` text COMMENT '邮箱地址',
  `REMARKS` text COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for gp_bm_next_action
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_next_action`;
CREATE TABLE `gp_bm_next_action` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `CORP_ID` varchar(14) NOT NULL COMMENT '法人机构号',
  `CURR_DATA_STATUS` char(2) NOT NULL,
  `ACTION_ID` varchar(64) NOT NULL,
  `CONDITION_ID` varchar(64) NOT NULL,
  `FLOW_ID` varchar(64) DEFAULT NULL,
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `NEXT_ORG_ID` varchar(14) DEFAULT NULL,
  `NEXT_OPER` varchar(60) DEFAULT NULL,
  `IS_END` char(1) DEFAULT NULL,
  `SYS_ID` varchar(32) DEFAULT NULL,
  `DATA_BAK_FLAG` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='数据流表';

-- ----------------------------
-- Table structure for gp_bm_notice
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_notice`;
CREATE TABLE `gp_bm_notice` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `INQ_ORG_ID` char(24) DEFAULT NULL COMMENT '查询机构号',
  `INQ_GROUP_ID` char(24) DEFAULT NULL COMMENT '查询组号',
  `TOPIC` varchar(32) DEFAULT NULL,
  `TPL_ID` varchar(32) DEFAULT NULL,
  `REMARKS` varchar(180) DEFAULT NULL,
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='消息通知表';

-- ----------------------------
-- Table structure for gp_bm_notice_publish
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_notice_publish`;
CREATE TABLE `gp_bm_notice_publish` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `MODULE` char(30) DEFAULT NULL,
  `MENU` char(30) DEFAULT NULL,
  `RANK` char(1) DEFAULT NULL,
  `TYPE` char(1) DEFAULT NULL,
  `PUBLISH_DATE` char(8) DEFAULT NULL,
  `EFFECTIVE_DATE` char(8) DEFAULT NULL,
  `NOTICE_CONTENT` text,
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `SCOPE` char(1) DEFAULT NULL,
  `TITLE` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='公告表';

-- ----------------------------
-- Table structure for gp_bm_notice_publish_scope
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_notice_publish_scope`;
CREATE TABLE `gp_bm_notice_publish_scope` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `NOTICE_ID` char(32) DEFAULT NULL,
  `DEPART_ID` varchar(32) DEFAULT NULL,
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='公告关联机构表';

-- ----------------------------
-- Table structure for gp_bm_page_detail
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_page_detail`;
CREATE TABLE `gp_bm_page_detail` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARK` text COMMENT '备注',
  `NAME` text COMMENT '类型名称',
  `DESC_INFO` text COMMENT '类型描述',
  `PAGFE_URL` text COMMENT '关联页面url',
  `PARAM_LIST` text COMMENT '页面参数',
  `PARENT` char(32) DEFAULT NULL COMMENT '上级ITEM',
  `UPID` char(32) DEFAULT NULL COMMENT '上级明细对象ID',
  `SEQID` decimal(65,30) DEFAULT NULL COMMENT '显示顺序',
  `OPT_DETAILS` text COMMENT '关联动作',
  `STATUS` char(1) DEFAULT NULL COMMENT '状态',
  `LAST_UPD_TLR` varchar(20) DEFAULT NULL COMMENT '最后更新人',
  `LAST_UPD_TIME` char(17) DEFAULT NULL COMMENT '最后更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='页面组合明细表';

-- ----------------------------
-- Table structure for gp_bm_page_item
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_page_item`;
CREATE TABLE `gp_bm_page_item` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARK` text COMMENT '备注',
  `NAME` text COMMENT '组合对象名称',
  `DESC_INFO` text COMMENT '描述信息',
  `TYPEID` char(32) DEFAULT NULL COMMENT '类型ID',
  `VIEWTYPE` char(1) DEFAULT NULL COMMENT '组装类型 0,tab;1,accordion;2,tree',
  `DEFAULTNO` char(32) DEFAULT NULL COMMENT '默认进入',
  `OP_ITEM_ID` char(32) DEFAULT NULL COMMENT '关联功能组Id',
  `STATUS` char(1) DEFAULT NULL COMMENT '状态',
  `LAST_UPD_TLR` varchar(20) DEFAULT NULL COMMENT '最后更新人',
  `LAST_UPD_TIME` char(17) DEFAULT NULL COMMENT '最后更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='页面组合表';

-- ----------------------------
-- Table structure for gp_bm_page_opt_detail
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_page_opt_detail`;
CREATE TABLE `gp_bm_page_opt_detail` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARK` text COMMENT '备注',
  `NAME` text COMMENT '类型名称',
  `DESC_INFO` text COMMENT '类型描述',
  `OPERATION` char(1) DEFAULT NULL COMMENT '动作类型 0,自定义;1,数据提交;2,数据查询;3,超链接',
  `OPT_CLAZZ` text COMMENT '执行CLASS',
  `OPT_SCRIPT` text COMMENT '动作事件脚本',
  `DEFAULT_CQID` varchar(64) DEFAULT NULL COMMENT '默认数据集ID',
  `PARENT` char(32) DEFAULT NULL COMMENT '上级ID',
  `STATUS` char(1) DEFAULT NULL COMMENT '状态',
  `SEQID` decimal(65,30) DEFAULT NULL COMMENT '显示顺序',
  `ICON` varchar(30) DEFAULT NULL COMMENT '图标',
  `LAST_UPD_TLR` varchar(20) DEFAULT NULL COMMENT '最后更新人',
  `LAST_UPD_TIME` char(17) DEFAULT NULL COMMENT '最后更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='页面动作明细表';

-- ----------------------------
-- Table structure for gp_bm_page_opt_item
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_page_opt_item`;
CREATE TABLE `gp_bm_page_opt_item` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARK` text COMMENT '备注',
  `NAME` text COMMENT '动作组标识',
  `DESC_INFO` text COMMENT '描述信息',
  `TYPEID` char(32) DEFAULT NULL COMMENT '类型ID',
  `VIEWTYPE` char(1) DEFAULT NULL COMMENT '组装类型',
  `STATUS` char(1) DEFAULT NULL COMMENT '状态',
  `LAST_UPD_TLR` varchar(20) DEFAULT NULL COMMENT '最后更新人',
  `LAST_UPD_TIME` char(17) DEFAULT NULL COMMENT '最后更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='页面动作表';

-- ----------------------------
-- Table structure for gp_bm_page_type
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_page_type`;
CREATE TABLE `gp_bm_page_type` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARK` text COMMENT '备注',
  `NAME` text COMMENT '类型名称',
  `DESC_INFO` text COMMENT '类型描述',
  `TYPE` char(1) DEFAULT NULL COMMENT '类别 0,目录;1,页面组装;2,功能组装',
  `PARENT` char(32) DEFAULT NULL COMMENT '上级',
  `FUN_ID` char(32) DEFAULT NULL COMMENT '菜单ID',
  `STATUS` char(1) DEFAULT NULL COMMENT '状态 0,无效;1,有效',
  `LAST_UPD_TLR` varchar(20) DEFAULT NULL COMMENT '最后更新人',
  `LAST_UPD_TIME` char(17) DEFAULT NULL COMMENT '最后更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='页面配置类型表';

-- ----------------------------
-- Table structure for gp_bm_password_his
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_password_his`;
CREATE TABLE `gp_bm_password_his` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `INQ_ORG_ID` char(24) DEFAULT NULL COMMENT '查询机构号',
  `INQ_GROUP_ID` char(24) DEFAULT NULL COMMENT '查询组号',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `TLR_NO` varchar(20) DEFAULT NULL COMMENT '操作员ID',
  `PASSWORD` varchar(80) DEFAULT NULL COMMENT '密码',
  `PASSWD_ENC` varchar(10) DEFAULT NULL COMMENT '密码加密算法',
  `MODIFIED_TIME` char(14) DEFAULT NULL COMMENT '修改时间',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_OP` char(1) DEFAULT NULL COMMENT '数据操作 A：新增，D:删除, M:修改',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `DATA_HASH` varchar(64) DEFAULT NULL COMMENT '记录HASH值',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='记录用户密码的修改历史';

-- ----------------------------
-- Table structure for gp_bm_priv_f_define
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_priv_f_define`;
CREATE TABLE `gp_bm_priv_f_define` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `F_ID` varchar(60) DEFAULT NULL COMMENT '功能ID',
  `F_TYPE` char(1) DEFAULT NULL COMMENT '功能类型 V-画面   I-接口',
  `CODE_SCHEMA` varchar(30) DEFAULT NULL COMMENT '采用的数据编码方案',
  `ENABLE_FLAG` char(1) DEFAULT NULL COMMENT '权限启用开关 1-开启   2-关闭',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='功能配置表';

-- ----------------------------
-- Table structure for gp_bm_priv_f_fields
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_priv_f_fields`;
CREATE TABLE `gp_bm_priv_f_fields` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `F_ID` varchar(20) NOT NULL COMMENT '功能ID',
  `FIELD_ID` varchar(60) NOT NULL COMMENT '字段ID',
  `FIELD_NAME` varchar(60) NOT NULL COMMENT '字段中文名',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='功能字段定义表';

-- ----------------------------
-- Table structure for gp_bm_priv_f_map
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_priv_f_map`;
CREATE TABLE `gp_bm_priv_f_map` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `F_ID` varchar(20) NOT NULL COMMENT '功能ID',
  `FIELD_ID` varchar(60) NOT NULL COMMENT '字段ID',
  `CODE_SCHEMA` varchar(30) NOT NULL COMMENT '编码方案',
  `CODE_ITEM` varchar(30) NOT NULL COMMENT '数据代码',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='功能字段与数据编码映射表';

-- ----------------------------
-- Table structure for gp_bm_priv_grant
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_priv_grant`;
CREATE TABLE `gp_bm_priv_grant` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CODE_SCHEMA` varchar(30) DEFAULT NULL COMMENT '编码方案',
  `CODE_ITEM` varchar(30) DEFAULT NULL COMMENT '编码项',
  `CODE_VALUE` varchar(30) DEFAULT NULL COMMENT '数据代码',
  `DATA_ORG_ID` varchar(14) DEFAULT NULL COMMENT '数据所属机构ID THIS-自己数据  CHILD-下属机构数据   机构号-机构号的数据',
  `ENT_TYPE` char(1) DEFAULT NULL COMMENT '组表号 U-用户  R-角色',
  `ENT_ID` varchar(32) DEFAULT NULL COMMENT '主体类型 0-一般纳税人 1-小规模纳税人 ',
  `PRIV_ALLOW` char(1) DEFAULT NULL COMMENT '权限 N-没有权限  R-只读   W-可写',
  `GRANT_FLAG` char(1) DEFAULT NULL COMMENT '授权标志 N-不能向他人授权本权限  Y-可向他人授权本权限',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='数据权限授权表';

-- ----------------------------
-- Table structure for gp_bm_role_func_rel
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_role_func_rel`;
CREATE TABLE `gp_bm_role_func_rel` (
  `ID` char(32) NOT NULL COMMENT '数据ID',
  `ROLE_ID` varchar(32) DEFAULT NULL COMMENT '角色Id',
  `FUNCID` varchar(32) DEFAULT NULL COMMENT '菜单Id',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARKS` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色资源映射表';

-- ----------------------------
-- Table structure for gp_bm_role_func_rel_pending
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_role_func_rel_pending`;
CREATE TABLE `gp_bm_role_func_rel_pending` (
  `ID` char(32) NOT NULL COMMENT '数据ID',
  `ROLE_ID` varchar(32) DEFAULT NULL COMMENT '角色Id',
  `FUNCID` varchar(32) DEFAULT NULL COMMENT '菜单Id',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARKS` varchar(180) DEFAULT NULL,
  `GPMS_NEXT_ACTION` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色资源映射pending表';

-- ----------------------------
-- Table structure for gp_bm_role_info
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_role_info`;
CREATE TABLE `gp_bm_role_info` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `ROLE_ID` varchar(32) DEFAULT NULL,
  `ROLE_NAME` varchar(90) DEFAULT NULL COMMENT '1有效;0无效',
  `STATUS` char(1) DEFAULT NULL,
  `EFFECT_DATE` char(8) DEFAULT NULL,
  `EXPIRE_DATE` char(8) DEFAULT NULL,
  `LAST_UPD_DATE` char(8) DEFAULT NULL,
  `LAST_UPD_FUNC` decimal(65,30) DEFAULT NULL,
  `LAST_UPD_TLR` char(8) DEFAULT NULL,
  `MISCFLGS` char(20) DEFAULT NULL,
  `MISC` text,
  `ROLE_TYPE` char(1) DEFAULT NULL,
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARKS` varchar(180) DEFAULT NULL,
  `IS_LOCK` char(1) DEFAULT NULL,
  `ST` char(1) DEFAULT NULL,
  `CRT_DT` char(8) DEFAULT NULL,
  `GPMS_NEXTACTION` varchar(2) DEFAULT NULL,
  `BUSINESS_LINE` text,
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色表';

-- ----------------------------
-- Table structure for gp_bm_role_info_pending
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_role_info_pending`;
CREATE TABLE `gp_bm_role_info_pending` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `ROLE_ID` varchar(32) DEFAULT NULL COMMENT '岗位ID',
  `ROLE_NAME` varchar(90) DEFAULT NULL COMMENT '岗位名称',
  `STATUS` char(1) DEFAULT NULL COMMENT '状态',
  `EFFECT_DATE` char(8) DEFAULT NULL COMMENT '有效日期开始',
  `EXPIRE_DATE` char(8) DEFAULT NULL COMMENT '有效日期结束',
  `LAST_UPD_DATE` char(8) DEFAULT NULL COMMENT '最后更新日期',
  `LAST_UPD_FUNC` decimal(65,30) DEFAULT NULL COMMENT '最后更新功能ID',
  `LAST_UPD_TLR` char(8) DEFAULT NULL COMMENT '最后更新人',
  `MISCFLGS` char(20) DEFAULT NULL COMMENT '扩展标志位',
  `MISC` text COMMENT '扩展标志位',
  `ROLE_TYPE` char(1) DEFAULT NULL COMMENT '角色类型：枚举',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注',
  `IS_LOCK` char(1) DEFAULT NULL,
  `ST` char(1) DEFAULT NULL,
  `CRT_DT` char(8) DEFAULT NULL,
  `GPMS_NEXT_ACTION` varchar(2) DEFAULT NULL,
  `BUSINESS_LINE` text,
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色pending表';

-- ----------------------------
-- Table structure for gp_bm_role_org_rel
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_role_org_rel`;
CREATE TABLE `gp_bm_role_org_rel` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `ROLE_ID` varchar(32) DEFAULT NULL COMMENT '岗位ID',
  `CHG_ORG_ID` varchar(32) DEFAULT NULL COMMENT '机构ID',
  `REMARK` text COMMENT '备注',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `GPMS_NEXTACTION` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色允许切换机构配置表';

-- ----------------------------
-- Table structure for gp_bm_role_org_rel_pending
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_role_org_rel_pending`;
CREATE TABLE `gp_bm_role_org_rel_pending` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `ROLE_ID` varchar(32) DEFAULT NULL COMMENT '岗位ID',
  `CHG_ORG_ID` varchar(32) DEFAULT NULL COMMENT '机构ID',
  `REMARK` text COMMENT '备注',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `GPMS_NEXTACTION` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色允许切换机构配置pending表';

-- ----------------------------
-- Table structure for gp_bm_schedules
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_schedules`;
CREATE TABLE `gp_bm_schedules` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `ID` decimal(65,30) DEFAULT NULL,
  `OBJ_VERSION` decimal(65,30) DEFAULT NULL,
  `CREATED` char(8) DEFAULT NULL,
  `LAST_MODIFIED` char(8) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `TYPE` varchar(20) DEFAULT NULL,
  `RUN_DETAIL` varchar(255) DEFAULT NULL,
  `STATUS` varchar(20) DEFAULT NULL,
  `RUN_SECOND` varchar(255) DEFAULT NULL,
  `RUN_MINUTE` varchar(255) DEFAULT NULL,
  `RUN_HOUR` varchar(255) DEFAULT NULL,
  `RUN_DAY_IN_MONTH` varchar(255) DEFAULT NULL,
  `RUN_MONTH` varchar(255) DEFAULT NULL,
  `RUN_DAY_IN_WEEK` varchar(255) DEFAULT NULL,
  `RUN_YEAR` varchar(255) DEFAULT NULL,
  `JOB_ID` decimal(65,30) DEFAULT NULL,
  `RUN_STATUS` decimal(65,30) DEFAULT NULL,
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='任务执行计划表';

-- ----------------------------
-- Table structure for gp_bm_sys_param
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_sys_param`;
CREATE TABLE `gp_bm_sys_param` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `PARAM_ID` varchar(20) DEFAULT NULL COMMENT '参数ID',
  `PARAM_GROUP_ID` varchar(20) DEFAULT NULL COMMENT '参数组号',
  `PARAM_START_DT` char(8) DEFAULT NULL COMMENT '有效期起',
  `PARAM_END_DT` char(8) DEFAULT NULL COMMENT '有效止日',
  `PARAM_NAME` text COMMENT '参数名称',
  `PARAM_VALUE` text COMMENT '参数值',
  `LOAD_TYPE` char(1) DEFAULT NULL COMMENT '加载方式',
  `IF_CANMODIFY` char(1) DEFAULT NULL COMMENT '是否可修改',
  `LAST_UPD_TLR` char(8) DEFAULT NULL COMMENT '最后更新操作员',
  `LAST_UPD_FUNC` varchar(10) DEFAULT NULL COMMENT '最后修改交易码',
  `LAST_UPD_DATE` char(8) DEFAULT NULL COMMENT '最后更新时间',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注',
  `CATALOG` varchar(20) DEFAULT NULL COMMENT '参数分类',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统参数表';

-- ----------------------------
-- Table structure for gp_bm_sys_stat
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_sys_stat`;
CREATE TABLE `gp_bm_sys_stat` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `SYSTEM_NAME` varchar(20) DEFAULT NULL COMMENT '系统简称',
  `SYS_DATE` char(8) DEFAULT NULL COMMENT '系统日期',
  `LAST_WORK_DATE` char(8) DEFAULT NULL COMMENT '上一工作日',
  `WORK_DATE` char(8) DEFAULT NULL COMMENT '工作日',
  `NEXT_WORK_DATE` char(8) DEFAULT NULL COMMENT '下一工作日',
  `BH_DATE` char(8) DEFAULT NULL COMMENT '批量日期',
  `REPORT_DATE` char(8) DEFAULT NULL COMMENT '报告期',
  `CURR_REPORT_DATE` char(8) DEFAULT NULL COMMENT '当前报告期',
  `STATUS` char(1) DEFAULT NULL COMMENT '状态 0-联机状态；1-批量状态',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统状态表';

-- ----------------------------
-- Table structure for gp_bm_table_check_config
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_table_check_config`;
CREATE TABLE `gp_bm_table_check_config` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `INQ_ORG_ID` char(24) DEFAULT NULL COMMENT '查询机构号',
  `INQ_GROUP_ID` char(24) DEFAULT NULL COMMENT '查询组号',
  `CK_GROUP` varchar(32) NOT NULL COMMENT '检验组',
  `TABLE_NAME` varchar(128) DEFAULT NULL,
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `SEQ_NO` decimal(65,30) DEFAULT NULL,
  `CONDITIONS` text,
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `TABLE_COMMENTS` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for gp_bm_table_check_config_dtl
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_table_check_config_dtl`;
CREATE TABLE `gp_bm_table_check_config_dtl` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `INQ_ORG_ID` char(24) DEFAULT NULL COMMENT '查询机构号',
  `INQ_GROUP_ID` char(24) DEFAULT NULL COMMENT '查询组号',
  `CK_GROUP` varchar(32) NOT NULL,
  `CHECK_TYPE` char(1) DEFAULT NULL,
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `SEQ_NO` decimal(65,30) DEFAULT NULL,
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  UNIQUE KEY `SYS_C00245219` (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for gp_bm_table_fields
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_table_fields`;
CREATE TABLE `gp_bm_table_fields` (
  `SYS_ID` varchar(30) NOT NULL COMMENT '系统ID',
  `FIELD_ID` varchar(30) DEFAULT NULL COMMENT '字段ID',
  `FIELD_ALIAS` varchar(30) DEFAULT NULL COMMENT '字段别名',
  `FIELD_NAME` varchar(64) DEFAULT NULL COMMENT '中文名称',
  `FIELD_TYPE` varchar(14) DEFAULT NULL COMMENT '字段类型',
  `FIELD_SIZE` decimal(65,30) DEFAULT NULL COMMENT '字段长度',
  `FIELD_PRECISION` decimal(65,30) DEFAULT NULL COMMENT '字段精度',
  `FIELD_FORMULA` varchar(128) DEFAULT NULL COMMENT '字段取值规则',
  `DEFUALT_VALUE` text COMMENT '默认值',
  `REMARKS` text COMMENT '备注',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='常用字段配置表';

-- ----------------------------
-- Table structure for gp_bm_task
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_task`;
CREATE TABLE `gp_bm_task` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `INQ_ORG_ID` char(24) DEFAULT NULL COMMENT '查询机构号',
  `INQ_GROUP_ID` char(24) DEFAULT NULL COMMENT '查询组号',
  `INSTANCE_NAME` varchar(32) DEFAULT NULL COMMENT '实例名称',
  `USER_ID` varchar(64) DEFAULT NULL COMMENT '用户 ID',
  `MODULE` varchar(32) DEFAULT NULL COMMENT '模块/菜单 ID',
  `ACTION` varchar(32) DEFAULT NULL COMMENT '画面动作',
  `PARALLELISM` decimal(8,0) DEFAULT NULL COMMENT '并发数量',
  `STATUS` char(2) DEFAULT NULL COMMENT '状态 0-排队 1-执行中 2-成功 3-失败',
  `RESULT` varchar(128) DEFAULT NULL COMMENT '运行结果',
  `ERROR_MESSAGE` text COMMENT '错误信息',
  `STACK_TRACE` text COMMENT '堆栈信息',
  `START_TIME` char(14) DEFAULT NULL COMMENT '开始时间',
  `END_TIME` char(14) DEFAULT NULL COMMENT '结束时间',
  `REF_ID` varchar(64) DEFAULT NULL COMMENT '关联 ID',
  `EXT1` text COMMENT '扩展数据1',
  `EXT2` text COMMENT '扩展数据2',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_OP` char(1) DEFAULT NULL COMMENT '数据操作 A：新增，D:删除, M:修改',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='批量任务执行日志表';

-- ----------------------------
-- Table structure for gp_bm_task_config
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_task_config`;
CREATE TABLE `gp_bm_task_config` (
  `MODE_NAME` varchar(150) DEFAULT NULL,
  `BEAN_ID` varchar(150) DEFAULT NULL,
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `EXT` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='批量任务配置表';

-- ----------------------------
-- Table structure for gp_bm_template_export
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_template_export`;
CREATE TABLE `gp_bm_template_export` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `FUNCID` varchar(32) DEFAULT NULL,
  `FUNC_NAME` text,
  `TABLE_NAME` varchar(128) DEFAULT NULL,
  `TABLE_COMMENTS` text,
  `COLUMN_NAME` text,
  `COLUMN_COMMENTS` text,
  `IS_NEED` varchar(1) DEFAULT NULL,
  `SEQ_NO` varchar(32) DEFAULT NULL,
  `NUM` decimal(65,30) DEFAULT NULL,
  `IS_RELATION` varchar(1) DEFAULT NULL,
  `GUID` varchar(32) DEFAULT NULL,
  `HAS_SQL` varchar(1) DEFAULT NULL,
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='文件导出配置表';

-- ----------------------------
-- Table structure for gp_bm_tlr_info
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_tlr_info`;
CREATE TABLE `gp_bm_tlr_info` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `TLRNO` varchar(20) DEFAULT NULL COMMENT '操作员编号',
  `TLR_NAME` varchar(30) DEFAULT NULL COMMENT '操作员名称',
  `TLR_TYPE` char(1) DEFAULT NULL COMMENT '操作员类型',
  `AGENT_TYPE` char(1) DEFAULT NULL,
  `PASSWORD` varchar(80) DEFAULT NULL COMMENT '操作员密码',
  `PASSWD_ENC` varchar(10) DEFAULT NULL COMMENT '密码加密算法',
  `CHEK_DPWD_FLG` char(1) DEFAULT NULL COMMENT '是否校验动态码',
  `BRCODE` varchar(20) DEFAULT NULL COMMENT '内部机构号',
  `BRNO` varchar(32) DEFAULT NULL COMMENT '机构代码',
  `ROLE_ID` varchar(32) DEFAULT NULL COMMENT '默认岗位',
  `LOGIN_IP` varchar(20) DEFAULT NULL COMMENT '登录IP',
  `STATUS` char(1) DEFAULT NULL COMMENT '有效标识 0-签退；1-签到；2-离职',
  `ST` char(1) DEFAULT NULL COMMENT '记录状态 1-创建中；2-修改中；3-删除中；4-可用',
  `IS_LOCK` char(1) DEFAULT NULL COMMENT '是否锁定 0-未锁定;1-锁定',
  `LOCK_REASON` varchar(200) DEFAULT NULL COMMENT '锁定原因',
  `LAST_ACCESS_TIME` char(14) DEFAULT NULL COMMENT '上次成功登录时间',
  `LAST_LOGOUT_TIME` char(14) DEFAULT NULL COMMENT '上次登出时间',
  `LAST_FAILED_TIME` char(14) DEFAULT NULL COMMENT '上次登陆失败时间',
  `PSWD_ERR_CNT` decimal(65,30) DEFAULT NULL COMMENT '密码输入错次数',
  `TOT_PSWD_ERR_CNT` decimal(65,30) DEFAULT NULL COMMENT '密码连续错误次数',
  `PSWD_ERR_DATE` char(8) DEFAULT NULL COMMENT '密码输入错误日期',
  `FAIL_MAX_CNT` decimal(65,30) DEFAULT NULL COMMENT '最大错误输入次数',
  `PASSWD_CHG_INTERVA` decimal(65,30) DEFAULT NULL COMMENT '密码更换间隔天数',
  `PASSWD_WARN_INTERVAL` decimal(65,30) DEFAULT NULL COMMENT '密码更换提醒天数',
  `LAST_PWD_CHG_TIME` char(14) DEFAULT NULL COMMENT '上次密码修改时间',
  `SESSION_ID` text COMMENT '会话ID',
  `MSRNO` decimal(65,30) DEFAULT NULL COMMENT '机构流水号',
  `FLAG` char(1) DEFAULT NULL COMMENT '标志',
  `CREDATE_DATE` char(8) DEFAULT NULL COMMENT '创建时间',
  `LAST_UPD_OPR_ID` char(20) DEFAULT NULL COMMENT '最后更新操作员',
  `LAST_UPD_TIME` char(14) DEFAULT NULL COMMENT '最后更新时间',
  `EFFECT_DATE` char(8) DEFAULT NULL COMMENT '生效日期',
  `EXPIRE_DATE` char(8) DEFAULT NULL COMMENT '失效日期',
  `EMAIL` varchar(100) DEFAULT NULL COMMENT 'EMAIL',
  `MISC` varchar(156) DEFAULT NULL COMMENT '扩展域',
  `DEPARTMENT_CODE` varchar(32) DEFAULT NULL,
  `EXT_TLRNO` char(20) DEFAULT NULL,
  `ID_NUMBER` varchar(35) DEFAULT NULL,
  `JOIN_DATE` char(8) DEFAULT NULL,
  `LEAVE_DATE` char(8) DEFAULT NULL,
  `INNER_FLAG` char(1) DEFAULT NULL,
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注',
  `GPMS_NEXTACTION` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`),
  UNIQUE KEY `IDX_GP_BM_TLR_INFO_01` (`TLRNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='操作员信息表';

-- ----------------------------
-- Table structure for gp_bm_tlr_info_pending
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_tlr_info_pending`;
CREATE TABLE `gp_bm_tlr_info_pending` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `TLRNO` varchar(20) DEFAULT NULL,
  `TLR_NAME` varchar(30) DEFAULT NULL,
  `TLR_TYPE` char(1) DEFAULT NULL,
  `AGENT_TYPE` char(1) DEFAULT NULL,
  `PASSWORD` varchar(80) DEFAULT NULL,
  `PASSWD_ENC` varchar(10) DEFAULT NULL,
  `CHEK_DPWD_FLG` char(1) DEFAULT NULL,
  `BRCODE` varchar(20) DEFAULT NULL,
  `BRNO` varchar(32) DEFAULT NULL,
  `ROLE_ID` decimal(65,30) DEFAULT NULL,
  `LOGIN_IP` varchar(20) DEFAULT NULL,
  `STATUS` char(1) DEFAULT NULL,
  `ST` char(1) DEFAULT NULL,
  `IS_LOCK` char(1) DEFAULT NULL,
  `LOCK_REASON` varchar(200) DEFAULT NULL,
  `LAST_ACCESS_TIME` char(14) DEFAULT NULL,
  `LAST_LOGOUT_TIME` char(14) DEFAULT NULL,
  `LAST_FAILED_TIME` char(14) DEFAULT NULL,
  `PSWD_ERR_CNT` decimal(65,30) DEFAULT NULL,
  `TOT_PSWD_ERR_CNT` decimal(65,30) DEFAULT NULL,
  `PSWD_ERR_DATE` char(8) DEFAULT NULL,
  `FAIL_MAX_CNT` decimal(65,30) DEFAULT NULL,
  `PASSWD_CHG_INTERVA` decimal(65,30) DEFAULT NULL,
  `PASSWD_WARN_INTERVAL` decimal(65,30) DEFAULT NULL,
  `LAST_PWD_CHG_TIME` char(14) DEFAULT NULL,
  `SESSION_ID` text,
  `MSRNO` decimal(65,30) DEFAULT NULL,
  `FLAG` char(1) DEFAULT NULL,
  `CREDATE_DATE` char(8) DEFAULT NULL,
  `LAST_UPD_OPR_ID` char(20) DEFAULT NULL,
  `LAST_UPD_TIME` char(14) DEFAULT NULL,
  `EFFECT_DATE` char(8) DEFAULT NULL,
  `EXPIRE_DATE` char(8) DEFAULT NULL,
  `EMAIL` varchar(100) DEFAULT NULL,
  `MISC` varchar(156) DEFAULT NULL,
  `DEPARTMENT_CODE` varchar(32) DEFAULT NULL,
  `EXT_TLRNO` char(20) DEFAULT NULL,
  `ID_NUMBER` varchar(35) DEFAULT NULL,
  `JOIN_DATE` char(8) DEFAULT NULL,
  `LEAVE_DATE` char(8) DEFAULT NULL,
  `INNER_FLAG` char(1) DEFAULT NULL,
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARKS` varchar(180) DEFAULT NULL,
  `GPMS_NEXTACTION` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='操作员信息pending表';

-- ----------------------------
-- Table structure for gp_bm_tlr_role_rel
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_tlr_role_rel`;
CREATE TABLE `gp_bm_tlr_role_rel` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `TLRNO` varchar(20) DEFAULT NULL COMMENT '操作员Id',
  `ROLE_ID` char(32) DEFAULT NULL COMMENT '角色Id',
  `STATUS` char(1) DEFAULT NULL COMMENT '状态',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `REMARKS` varchar(150) DEFAULT NULL,
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='操作员角色映射表';

-- ----------------------------
-- Table structure for gp_bm_tlr_role_rel_pending
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_tlr_role_rel_pending`;
CREATE TABLE `gp_bm_tlr_role_rel_pending` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `TLRNO` varchar(20) NOT NULL,
  `ROLE_ID` char(32) DEFAULT NULL,
  `STATUS` char(1) DEFAULT NULL,
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `REMARKS` varchar(150) DEFAULT NULL,
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='操作员角色映射pending表';

-- ----------------------------
-- Table structure for gp_bm_upload_cfg
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_upload_cfg`;
CREATE TABLE `gp_bm_upload_cfg` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `FILE_SERVICE` varchar(180) DEFAULT NULL COMMENT '文件服务',
  `FILE_EXTS` text COMMENT '允许扩展名',
  `EXCLUDE_EXTS` text COMMENT '排除文件扩展名列表',
  `MAX_SIZE` decimal(65,30) DEFAULT NULL COMMENT '文件最大大小',
  `FILE_CHARSET` varchar(32) DEFAULT NULL COMMENT '文件编码',
  `PERMISSION_TYPE` varchar(2) DEFAULT NULL COMMENT '控制方式',
  `PERMISSION_DATA` varchar(180) DEFAULT NULL COMMENT '控制方式数据',
  `SAVE_PATH` text COMMENT '存放路径',
  `FILE_NAME_TPL` varchar(180) DEFAULT NULL COMMENT '文件名模板',
  `JOB_TYPE` varchar(1) DEFAULT NULL COMMENT '类型',
  `AFTER_BEAN` varchar(180) DEFAULT NULL COMMENT '后续操作',
  `STATUS` varchar(2) DEFAULT NULL COMMENT '启用状态',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='文件上传配置表';

-- ----------------------------
-- Table structure for gp_bm_upload_log
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_upload_log`;
CREATE TABLE `gp_bm_upload_log` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `FILE_SERVICE` varchar(180) DEFAULT NULL COMMENT '文件服务',
  `REAL_PATH` text COMMENT '实际路径',
  `BEFORE_UPLOAD_NAME` varchar(180) DEFAULT NULL COMMENT '上传前文件名',
  `BEGIN_TIME` varchar(14) DEFAULT NULL COMMENT '开始上传时间',
  `END_TIME` varchar(14) DEFAULT NULL COMMENT '结束上传时间',
  `IP` varchar(30) DEFAULT NULL COMMENT '上传IP地址',
  `STATUS` varchar(2) DEFAULT NULL COMMENT '状态',
  `ERR_CODE` varchar(30) DEFAULT NULL COMMENT '错误码',
  `ERR_MSG` text COMMENT '错误信息',
  `REMARKS` varchar(180) DEFAULT NULL COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='文件上传日志表';

-- ----------------------------
-- Table structure for gp_bm_user_tab_cols
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_user_tab_cols`;
CREATE TABLE `gp_bm_user_tab_cols` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `TABLE_NAME` varchar(30) DEFAULT NULL,
  `COLUMN_NAME` varchar(30) DEFAULT NULL,
  `DATA_TYPE` varchar(106) DEFAULT NULL,
  `DATA_LENGTH` decimal(65,30) DEFAULT NULL,
  `DATA_PRECISION` decimal(65,30) DEFAULT NULL,
  `DATA_SCALE` decimal(65,30) DEFAULT NULL,
  `NULLABLE` varchar(1) DEFAULT NULL,
  `COLUMN_ID` decimal(65,30) DEFAULT NULL,
  `CHAR_LENGTH` decimal(65,30) DEFAULT NULL,
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='数据库用户表属性表';

-- ----------------------------
-- Table structure for gp_bm_widget_cfg
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_widget_cfg`;
CREATE TABLE `gp_bm_widget_cfg` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `INQ_ORG_ID` char(24) DEFAULT NULL COMMENT '查询机构号',
  `INQ_GROUP_ID` char(24) DEFAULT NULL COMMENT '查询组号',
  `FUNCID` varchar(50) DEFAULT NULL,
  `DEPART` varchar(30) DEFAULT NULL,
  `FIELDNAME` text,
  `TYPE` varchar(1) DEFAULT NULL COMMENT '显示类型',
  `REMARKS` text COMMENT '备注',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `USERNAMELIST` varchar(180) DEFAULT NULL,
  `FUNCNAMELIST` varchar(180) DEFAULT NULL,
  `FIELDPARTNAMELIST` varchar(180) DEFAULT NULL,
  `FIELDPART` varchar(180) DEFAULT NULL,
  `FIELDNAMEDESC` varchar(180) DEFAULT NULL,
  `BUTTONTYPE` varchar(180) DEFAULT NULL,
  `BUTTONPARTNAMELIST` varchar(180) DEFAULT NULL,
  `BUTTONPART` varchar(180) DEFAULT NULL,
  `BUTTONNAME` varchar(180) DEFAULT NULL,
  `BUTTONID` varchar(180) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for gp_bm_workflow_entity
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_workflow_entity`;
CREATE TABLE `gp_bm_workflow_entity` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARK` text COMMENT '备注',
  `FLOW_ID` varchar(32) DEFAULT NULL COMMENT '流程ID',
  `TX_TIME` varchar(16) DEFAULT NULL COMMENT '交易日期',
  `TX_TYPE` varchar(32) DEFAULT NULL COMMENT '交易种类',
  `TX_CODE` varchar(32) DEFAULT NULL COMMENT '交易编码',
  `ACT_NO` varchar(32) DEFAULT NULL COMMENT '账号',
  `TX_AMT` decimal(65,30) DEFAULT NULL COMMENT '交易金额',
  `CNT_UNIT` varchar(60) DEFAULT NULL COMMENT '单位',
  `GOOD_NUM` decimal(65,30) DEFAULT NULL COMMENT '数量',
  `GOOD_AMT` decimal(65,30) DEFAULT NULL COMMENT '单价',
  `OP_TYPE` char(1) DEFAULT NULL COMMENT '操作类型 A：新增，U：更新，D：删除',
  `ENTITY_CLASS` varchar(100) DEFAULT NULL COMMENT '实体类型',
  `ENTITY` longtext COMMENT '数据体',
  `ENTITY_ID` varchar(32) DEFAULT NULL COMMENT '实体数据ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='工作流程实体数据表';

-- ----------------------------
-- Table structure for gp_bm_workflow_info
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_workflow_info`;
CREATE TABLE `gp_bm_workflow_info` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` text COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `DATA_VERSION` decimal(8,0) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  `REMARK` text COMMENT '备注',
  `APPLY_ID` char(32) DEFAULT NULL COMMENT '申请号',
  `DRAFT_ID` char(32) DEFAULT NULL COMMENT '草稿号',
  `BPM_NO` char(32) DEFAULT NULL COMMENT '流程编号',
  `BPM_NAME` text COMMENT '流程名称',
  `TASK_NAME` text COMMENT '任务名称',
  `APPLY_ORG_ID` varchar(14) DEFAULT NULL COMMENT '申请机构',
  `TASK_START_TIME` char(17) DEFAULT NULL COMMENT '任务发起时间',
  `TASK_END_TIME` char(17) DEFAULT NULL COMMENT '任务结束时间',
  `TASK_STATUS` char(2) DEFAULT NULL COMMENT '任务状态',
  `FUNC_ID` char(32) DEFAULT NULL COMMENT '菜单ID',
  `BIZ_TYPE` varchar(10) DEFAULT NULL COMMENT '业务类型',
  `BUTTON_ID` varchar(32) DEFAULT NULL COMMENT '按纽ID',
  `ACTION_TYPE` varchar(32) DEFAULT NULL COMMENT '动作类型',
  `ACTION_ID` varchar(50) DEFAULT NULL COMMENT '动作Id',
  `CONDITION_ID` varchar(32) DEFAULT NULL COMMENT '条件ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='工作流程实例表';

-- ----------------------------
-- Table structure for gp_bm_workflow_type
-- ----------------------------
DROP TABLE IF EXISTS `gp_bm_workflow_type`;
CREATE TABLE `gp_bm_workflow_type` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `FUNC_ID` varchar(32) DEFAULT NULL COMMENT '菜单ID',
  `BUTTON_ID` varchar(50) DEFAULT NULL COMMENT '按钮ID',
  `FLOW_TYPE` char(1) DEFAULT NULL COMMENT '流程类型N：nextaction,B：工作流',
  `TABLE_STYLE` char(1) DEFAULT NULL COMMENT '临时表模式1:原业务表 2:单独临时表 3:公共临时表'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='工作流类型定义表';

-- ----------------------------
-- Table structure for gp_qc_rule
-- ----------------------------
DROP TABLE IF EXISTS `gp_qc_rule`;
CREATE TABLE `gp_qc_rule` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID 规则 ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `INQ_ORG_ID` varchar(24) DEFAULT NULL COMMENT '查询机构号',
  `INQ_GROUP_ID` varchar(24) DEFAULT NULL COMMENT '查询组号',
  `RULE_DESC` varchar(512) DEFAULT NULL COMMENT '规则描述',
  `RULE_MESSAGE` varchar(3072) DEFAULT NULL COMMENT '校验信息 用于展示给前端用户',
  `RULE_TYPE` varchar(32) DEFAULT NULL COMMENT '规则类型',
  `RULE_SOURCE` varchar(32) DEFAULT NULL COMMENT '规则来源',
  `FIELD` varchar(128) DEFAULT NULL COMMENT '校验字段 UPPER_UNDERSCORE',
  `FIELD_NAME` varchar(128) DEFAULT NULL COMMENT '校验字段名称',
  `TRIMMABLE` char(1) DEFAULT NULL COMMENT '校验前是否需要清理空白字符 N-不需要（默认）；R-清理右侧空白字符；L-清理左侧空白字符；A-清理两侧空白字符',
  `NULLABLE` char(1) DEFAULT NULL COMMENT '是否允许为空 Y/N；默认为N；“空”指的是 NULL 或空字符串；字段为空时忽略其他校验规则',
  `TYPE_ID` varchar(64) DEFAULT NULL COMMENT '类型 ID 可为空',
  `ENCODING` varchar(32) DEFAULT NULL COMMENT '字符编码 用于字段长度校验；为空表示校验字符个数',
  `MIN_LENGTH` int(11) DEFAULT NULL COMMENT '字段长度下限 含下限',
  `MAX_LENGTH` int(11) DEFAULT NULL COMMENT '字段长度上限 含上限',
  `MIN_VALUE` decimal(32,10) DEFAULT NULL COMMENT '数值下限 含下限',
  `MAX_VALUE` decimal(32,10) DEFAULT NULL COMMENT '数值上限 含上限',
  `MAX_PRECISION` int(11) DEFAULT NULL COMMENT '数值总位数上限 含上限，0表示无限',
  `MIN_SCALE` int(11) DEFAULT NULL COMMENT '数值小数位数下限 含下限',
  `MAX_SCALE` int(11) DEFAULT NULL COMMENT '数值小数位数上限 含上限',
  `ENUMERATION` varchar(1000) DEFAULT NULL COMMENT '枚举值 以「,」分隔',
  `PATTERN` varchar(512) DEFAULT NULL COMMENT '正则表达式',
  `IN_ENTITY` varchar(128) DEFAULT NULL COMMENT '存在于某实体 IN_ENTITY 和 IN_FIELD 合并使用',
  `IN_FIELD` varchar(128) DEFAULT NULL COMMENT '存在于某字段',
  `SQL` varchar(1000) DEFAULT NULL COMMENT 'SQL 校验 以 SQL 能否查询到结果作为校验条件',
  `SCRIPT` varchar(3072) DEFAULT NULL COMMENT '校验脚本 Groovy',
  `BEAN` varchar(128) DEFAULT NULL COMMENT 'Spring Bean 名称',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` varchar(512) DEFAULT NULL COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_OP` char(1) DEFAULT NULL COMMENT '数据操作 A：新增，D:删除, M:修改',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` int(11) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='规则配置表';

-- ----------------------------
-- Table structure for gp_qc_rule_map
-- ----------------------------
DROP TABLE IF EXISTS `gp_qc_rule_map`;
CREATE TABLE `gp_qc_rule_map` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `INQ_ORG_ID` varchar(24) DEFAULT NULL COMMENT '查询机构号',
  `INQ_GROUP_ID` varchar(24) DEFAULT NULL COMMENT '查询组号',
  `RULE_SET_ID` varchar(64) DEFAULT NULL COMMENT '规则集 ID',
  `RULE_ID` varchar(64) DEFAULT NULL COMMENT '规则 ID',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` varchar(512) DEFAULT NULL COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_OP` char(1) DEFAULT NULL COMMENT '数据操作 A：新增，D:删除, M:修改',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` int(11) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  PRIMARY KEY (`DATA_ID`),
  UNIQUE KEY `GP_QC_RULE_MAP_UNIQ` (`RULE_SET_ID`,`RULE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='规则映射表';

-- ----------------------------
-- Table structure for gp_qc_rule_set
-- ----------------------------
DROP TABLE IF EXISTS `gp_qc_rule_set`;
CREATE TABLE `gp_qc_rule_set` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID 规则集 ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `INQ_ORG_ID` varchar(24) DEFAULT NULL COMMENT '查询机构号',
  `INQ_GROUP_ID` varchar(24) DEFAULT NULL COMMENT '查询组号',
  `RULE_SET_DESC` varchar(512) DEFAULT NULL COMMENT '规则集描述',
  `ENTITY` varchar(128) DEFAULT NULL COMMENT '实体名称',
  `MODULE` varchar(128) DEFAULT NULL COMMENT '模块',
  `ACTION` varchar(128) DEFAULT NULL COMMENT '动作',
  `SOURCE` varchar(128) DEFAULT NULL COMMENT '来源',
  `VERSION` varchar(128) DEFAULT NULL COMMENT '版本',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` varchar(512) DEFAULT NULL COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_OP` char(1) DEFAULT NULL COMMENT '数据操作 A：新增，D:删除, M:修改',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` int(11) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='规则集配置表';

-- ----------------------------
-- Table structure for gp_qc_type
-- ----------------------------
DROP TABLE IF EXISTS `gp_qc_type`;
CREATE TABLE `gp_qc_type` (
  `DATA_ID` varchar(64) NOT NULL COMMENT '数据ID 类型 ID',
  `DATA_DATE` char(8) DEFAULT NULL COMMENT '数据日期',
  `CORP_ID` varchar(14) DEFAULT NULL COMMENT '法人机构号',
  `ORG_ID` varchar(14) DEFAULT NULL COMMENT '机构号',
  `GROUP_ID` varchar(14) DEFAULT NULL COMMENT '部门编号',
  `INQ_ORG_ID` varchar(24) DEFAULT NULL COMMENT '查询机构号',
  `INQ_GROUP_ID` varchar(24) DEFAULT NULL COMMENT '查询组号',
  `TYPE_DESC` varchar(512) DEFAULT NULL COMMENT '类型描述',
  `ENCODING` varchar(32) DEFAULT NULL COMMENT '字符编码 用于字段长度校验；为空表示校验字符个数',
  `MIN_LENGTH` int(11) DEFAULT NULL COMMENT '字段长度下限 含下限',
  `MAX_LENGTH` int(11) DEFAULT NULL COMMENT '字段长度上限 含上限',
  `MIN_VALUE` decimal(32,10) DEFAULT NULL COMMENT '数值下限 含下限',
  `MAX_VALUE` decimal(32,10) DEFAULT NULL COMMENT '数值上限 含上限',
  `MAX_PRECISION` int(11) DEFAULT NULL COMMENT '数值总位数上限 含上限',
  `MIN_SCALE` int(11) DEFAULT NULL COMMENT '数值小数位数下限 含下限',
  `MAX_SCALE` int(11) DEFAULT NULL COMMENT '数值小数位数上限 含上限',
  `ENUMERATION` varchar(3072) DEFAULT NULL COMMENT '枚举值 以「,」分隔',
  `PATTERN` varchar(1024) DEFAULT NULL COMMENT '正则表达式',
  `IN_ENTITY` varchar(128) DEFAULT NULL COMMENT '存在于某实体 IN_ENTITY 和 IN_FIELD 合并使用',
  `IN_FIELD` varchar(128) DEFAULT NULL COMMENT '存在于某字段',
  `SQL` varchar(3072) DEFAULT NULL COMMENT 'SQL 校验 以 SQL 能否查询到结果作为校验条件',
  `SCRIPT` varchar(3072) DEFAULT NULL COMMENT '校验脚本 Groovy',
  `BEAN` varchar(128) DEFAULT NULL COMMENT 'Spring Bean 名称',
  `CHECK_FLAG` char(1) DEFAULT NULL COMMENT '校验标识',
  `CHECK_DESC` varchar(512) DEFAULT NULL COMMENT '校验结果',
  `CHECK_ERR_TYPE` char(1) DEFAULT NULL COMMENT '校验失败类型',
  `NEXT_ACTION` char(2) DEFAULT NULL COMMENT '下一动作',
  `DATA_STATUS` char(2) DEFAULT NULL COMMENT '数据状态',
  `DATA_FLAG` char(1) DEFAULT NULL COMMENT '数据是否已删除',
  `DATA_OP` char(1) DEFAULT NULL COMMENT '数据操作 A：新增，D:删除, M:修改',
  `DATA_SOURCE` char(1) DEFAULT NULL COMMENT '数据来源',
  `DATA_VERSION` int(11) DEFAULT NULL COMMENT '数据版本',
  `DATA_REJ_DESC` varchar(128) DEFAULT NULL COMMENT '数据审核拒绝原因',
  `DATA_DEL_DESC` varchar(128) DEFAULT NULL COMMENT '数据删除描述',
  `DATA_CRT_USER` varchar(20) DEFAULT NULL COMMENT '数据创建/导入用户',
  `DATA_CRT_DATE` char(8) DEFAULT NULL COMMENT '数据创建/导入日期',
  `DATA_CRT_TIME` char(14) DEFAULT NULL COMMENT '数据创建/导入时间',
  `DATA_CHG_USER` varchar(20) DEFAULT NULL COMMENT '数据修改/删除用户',
  `DATA_CHG_DATE` char(8) DEFAULT NULL COMMENT '数据修改/删除日期',
  `DATA_CHG_TIME` char(14) DEFAULT NULL COMMENT '数据修改/删除时间',
  `DATA_APV_USER` varchar(20) DEFAULT NULL COMMENT '数据审核/拒绝用户',
  `DATA_APV_DATE` char(8) DEFAULT NULL COMMENT '数据审核/拒绝日期',
  `DATA_APV_TIME` char(14) DEFAULT NULL COMMENT '数据审核/拒绝时间',
  `RSV1` varchar(180) DEFAULT NULL COMMENT '备用1',
  `RSV2` varchar(180) DEFAULT NULL COMMENT '备用2',
  `RSV3` varchar(180) DEFAULT NULL COMMENT '备用3',
  `RSV4` varchar(180) DEFAULT NULL COMMENT '备用4',
  `RSV5` varchar(180) DEFAULT NULL COMMENT '备用5',
  PRIMARY KEY (`DATA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='类型定义表';

-- ----------------------------
-- Function structure for fn_masking_zjlb
-- ----------------------------
DROP FUNCTION IF EXISTS `fn_masking_zjlb`;
delimiter ;;
CREATE FUNCTION `gfdr`.`fn_masking_zjlb`(zjlb_val  varchar(400),column_val varchar(400))
 RETURNS varchar(400) CHARSET utf8
begin
  if zjlb_val = '' or column_val = '' then
     return column_val;
  end if;

  if zjlb_val in ('统一社会信用代码','组织机构代码','无证件','其他') then
     return column_val;
  else
     return concat(get_str(column_val,6) , lower(md5(upper(column_val))));
  end if;
end
;;
delimiter ;

-- ----------------------------
-- Function structure for fn_masking_zjlb_mul
-- ----------------------------
DROP FUNCTION IF EXISTS `fn_masking_zjlb_mul`;
delimiter ;;
CREATE FUNCTION `gfdr`.`fn_masking_zjlb_mul`(zjlb_val varchar(400),column_val varchar(400))
 RETURNS varchar(400) CHARSET utf8
begin
    declare col_var varchar(600) default '';
    declare temp_int int;
    declare temp_num int;

  if zjlb_val = '' or column_val = '' then
     return column_val;
  end if;
  
    set temp_num = get_char_num(column_val,',');
    
    if temp_num = 0 then
        return fn_masking_zjlb(zjlb_val,column_val);
    end if;
      
    set temp_int = 1;
  
    WHILE temp_int <= temp_num + 1 DO
        if col_var = '' then
            set col_var = fn_masking_zjlb(split_str(zjlb_val,',',temp_int),split_str(column_val,',',temp_int));
        else
            set  col_var = concat(col_var,',',fn_masking_zjlb(split_str(zjlb_val,',',temp_int),split_str(column_val,',',temp_int)));
        end if;
        set temp_int = temp_int+1;
    END WHILE;

  return col_var;
end
;;
delimiter ;

-- ----------------------------
-- Function structure for FN_SECRET
-- ----------------------------
DROP FUNCTION IF EXISTS `FN_SECRET`;
delimiter ;;
CREATE FUNCTION `gfdr`.`FN_SECRET`(column_val  varchar(400),secret_mode varchar(400))
 RETURNS varchar(400) CHARSET utf8
begin
  if column_val = '' then
     return column_val;
  end if;

  if secret_mode = '1' and char_length(column_val) <= 3 then
  	return right(column_val, 1);
  end if;

  return column_val;
end
;;
delimiter ;

-- ----------------------------
-- Function structure for get_char_num
-- ----------------------------
DROP FUNCTION IF EXISTS `get_char_num`;
delimiter ;;
CREATE FUNCTION `gfdr`.`get_char_num`(col_val varchar(400),char_val varchar(400))
 RETURNS int(11)
begin
     return length(col_val) - length(replace(col_val,char_val,''));
end
;;
delimiter ;

-- ----------------------------
-- Function structure for GET_STR
-- ----------------------------
DROP FUNCTION IF EXISTS `GET_STR`;
delimiter ;;
CREATE FUNCTION `gfdr`.`GET_STR`(column_val varchar(400),len int)
 RETURNS varchar(400) CHARSET utf8
begin
  declare temp_int int;
  
  if column_val = '' then
     return column_val;
  end if;
  
  if length(column_val) = char_length(column_val) then
        return substr(column_val,1,len);
  end if;
  
  SET temp_int = 1;
  
  WHILE temp_int <= len DO
        if length(substr(column_val,1,temp_int)) = len then
                return substr(column_val,1,temp_int);
        end if;
        set temp_int = temp_int+1;
    END WHILE;
  return column_val;
end
;;
delimiter ;

-- ----------------------------
-- Function structure for split_str
-- ----------------------------
DROP FUNCTION IF EXISTS `split_str`;
delimiter ;;
CREATE FUNCTION `gfdr`.`split_str`(f_string varchar(1000),f_delimiter varchar(5),f_order int)
 RETURNS varchar(255) CHARSET utf8
BEGIN
declare result varchar(255) default ''; 
return  reverse(substring_index(reverse(substring_index(f_string,f_delimiter,f_order)),f_delimiter,1));
end
;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;
