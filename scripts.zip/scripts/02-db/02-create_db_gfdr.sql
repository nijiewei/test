create database gfdr;           
GRANT ALL PRIVILEGES ON  gfdr.* TO 'gfdr'@'127.0.0.1' IDENTIFIED BY 'gfdr';
GRANT ALL PRIVILEGES ON  gfdr.* TO 'gfdr'@'%' IDENTIFIED BY 'gfdr';            
flush privileges;